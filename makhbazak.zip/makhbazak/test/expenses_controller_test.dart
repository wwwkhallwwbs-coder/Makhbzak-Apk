import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:makhbazak/data/app_database.dart';
import 'package:makhbazak/data/day_repository.dart';
import 'package:makhbazak/data/device_repository.dart';
import 'package:makhbazak/data/expense_repository.dart';
import 'package:makhbazak/data/models.dart';
import 'package:makhbazak/data/settings_repository.dart';
import 'package:makhbazak/features/expenses/expenses_controller.dart';
import 'package:makhbazak/features/production/production_controller.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// اختبارات متحكم المصروفات على القاعدة الحقيقية (ffi). «اليوم» ثابت:
/// 2026-11-24، وبداية الوكيل 2026-11-23.
void main() {
  sqfliteFfiInit();

  late Database db;
  late DeviceInfo device;
  late DayRepository days;
  late ExpenseRepository expenses;
  late SettingsRepository settings;
  late ExpensesController controller;
  late String schemaSql;

  final DateTime today = DateTime(2026, 11, 24, 10);

  setUpAll(() {
    schemaSql = File('assets/db/schema.sql').readAsStringSync();
  });

  setUp(() async {
    db = await openAppDatabase(
      schemaSql: schemaSql,
      path: inMemoryDatabasePath,
      factory: databaseFactoryFfi,
    );
    device = await DeviceRepository(db).activateAsAgent(
      codeHash: 'a' * 64,
      bakeryName: 'مخبز التجربة',
      agentName: 'وكيل التجربة',
      startedAt: '2026-11-23',
    );
    settings = SettingsRepository(
      db,
      bakeryId: device.bakeryId!,
      deviceId: device.id,
    );
    days = DayRepository(
      db,
      bakeryId: device.bakeryId!,
      agentId: device.agentId!,
      deviceId: device.id,
    );
    expenses = ExpenseRepository(
      db,
      bakeryId: device.bakeryId!,
      agentId: device.agentId!,
      deviceId: device.id,
    );
    controller = ExpensesController(
      days: days,
      expenses: expenses,
      clock: () => today,
    );
  });

  tearDown(() async {
    controller.dispose();
    await db.close();
  });

  Future<void> setPrices() async {
    await settings.set(SettingKeys.windowPrice, 100);
    await settings.set(SettingKeys.distributionPrice, 90);
  }

  Future<void> openToday() async {
    await setPrices();
    await controller.load();
    await controller.openDay();
  }

  List<String> names(List<ExpenseRow> rows) => rows.map((e) => e.name).toList();

  group('التحميل والفتح', () {
    test('أول تحميل: اليوم الحالي غير مفتوح ولا أخطاء', () async {
      await controller.load();

      expect(controller.loading, isFalse);
      expect(controller.loadFailed, isFalse);
      expect(controller.startDate, '2026-11-23');
      expect(controller.date, '2026-11-24');
      expect(controller.isToday, isTrue);
      expect(controller.day, isNull);
      expect(controller.totals, isNull);
      expect(controller.monthly, isNull);
      expect(controller.error, isNull);
    });

    test('فتح اليوم بلا أسعار يطلب الإعدادات', () async {
      await controller.load();
      await controller.openDay();

      expect(controller.needsSettings, isTrue);
      expect(controller.day, isNull);
    });

    test('فتح اليوم بالأسعار: بنود فارغة ومجاميع صفر', () async {
      await openToday();

      expect(controller.day, isNotNull);
      expect(controller.fixed, isEmpty);
      expect(controller.variable, isEmpty);
      expect(controller.personal, isEmpty);
      expect(controller.totals!.general, 0);
      expect(controller.monthly!.count, 0);
      expect(controller.monthly!.total, 0);
    });

    test('التاريخ يُقيَّد بين بداية الوكيل واليوم', () async {
      await controller.load('2026-12-30');
      expect(controller.date, '2026-11-24');
      expect(controller.canGoNext, isFalse);
      expect(controller.canGoPrevious, isTrue);

      await controller.load('2026-01-01');
      expect(controller.date, '2026-11-23');
      expect(controller.canGoPrevious, isFalse);
      expect(controller.canGoNext, isTrue);
    });
  });

  group('البنود والمجاميع (أرقام التصميم)', () {
    test('ثابت 220,000 + متحرك 25,000 = 245,000، وشخصي 12,000', () async {
      await openToday();
      expect(await controller.addItem(ExpenseKind.fixed, 'العمال', 150000), isNull);
      expect(await controller.addItem(ExpenseKind.fixed, 'النظافة', 20000), isNull);
      expect(await controller.addItem(ExpenseKind.fixed, 'أجر البنكجي', 50000), isNull);
      expect(await controller.addItem(ExpenseKind.variable, 'صيانة', 15000), isNull);
      expect(await controller.addItem(ExpenseKind.variable, 'مواصلات', 10000), isNull);
      expect(await controller.addItem(ExpenseKind.personal, 'مصروف شخصي', 12000), isNull);

      expect(names(controller.fixed), ['العمال', 'النظافة', 'أجر البنكجي']);
      expect(names(controller.variable), ['صيانة', 'مواصلات']);
      expect(names(controller.personal), ['مصروف شخصي']);
      expect(controller.totals!.fixed, 220000);
      expect(controller.totals!.variable, 25000);
      expect(controller.totals!.general, 245000);
      expect(controller.totals!.personal, 12000);
      expect(controller.monthly!.count, 1);
      expect(controller.monthly!.total, 12000);
      expect(controller.error, isNull);
    });

    test('التعديل والحذف يحدّثان القوائم والمجاميع', () async {
      await openToday();
      await controller.addItem(ExpenseKind.variable, 'صيانة', 15000);
      await controller.addItem(ExpenseKind.variable, 'مواصلات', 10000);

      await controller.updateItem(controller.variable.first, 'صيانة الفرن', 20000);
      await controller.removeItem(controller.variable.last);

      expect(names(controller.variable), ['صيانة الفرن']);
      expect(controller.totals!.variable, 20000);
      expect(controller.totals!.general, 20000);
    });

    test('المشكلات ترجع رسالة ولا تغيّر القوائم: اسم فارغ ومكرر ومبلغ سالب', () async {
      await openToday();
      await controller.addItem(ExpenseKind.fixed, 'العمال', 150000);

      final empty = await controller.addItem(ExpenseKind.fixed, '  ', 1);
      final duplicate = await controller.addItem(ExpenseKind.fixed, 'العمال', 1);
      final negative = await controller.addItem(ExpenseKind.variable, 'خصم', -5);

      expect(empty, isNotNull);
      expect(duplicate, 'يوجد بند ثابت بهذا الاسم');
      expect(negative, isNotNull);
      expect(names(controller.fixed), ['العمال']);
      expect(controller.variable, isEmpty);
      expect(controller.error, isNull);
    });

    test('الكتابة قبل فتح اليوم ترفع «افتح اليوم أولاً»', () async {
      await controller.load();
      final problem = await controller.addItem(ExpenseKind.variable, 'صيانة', 1);

      expect(problem, isNull);
      expect(controller.error, 'افتح اليوم أولاً');
    });
  });

  group('الثوابت بين الأيام', () {
    test('الثابت المضاف اليوم ينتقل إلى اليوم التالي', () async {
      await openToday();
      await controller.addItem(ExpenseKind.fixed, 'العمال', 150000);
      await controller.addItem(ExpenseKind.variable, 'صيانة', 15000);

      final tomorrow = await days.getOrCreate('2026-11-25');
      final rows = await expenses.forDay(tomorrow.id);
      expect(names(rows), ['العمال']);
      expect(rows.single.amount, 150000);
    });

    test('حذف ثابت اليوم يزيله من الأيام القادمة', () async {
      await openToday();
      await controller.addItem(ExpenseKind.fixed, 'العمال', 150000);
      await controller.addItem(ExpenseKind.fixed, 'النظافة', 20000);
      await controller.removeItem(controller.fixed.last);

      final tomorrow = await days.getOrCreate('2026-11-25');
      expect(names(await expenses.forDay(tomorrow.id)), ['العمال']);
    });

    test('تعديل ثابت يوم سابق لا يغيّر قالبه ولا اليوم الحالي', () async {
      await openToday();
      await controller.addItem(ExpenseKind.fixed, 'العمال', 150000);

      await controller.goToPrevious();
      expect(controller.date, '2026-11-23');
      expect(controller.isToday, isFalse);
      expect(controller.day, isNull);
      await controller.openDay();
      // اليوم السابق فُتح الآن فنُسخت إليه الثوابت.
      expect(controller.fixed.single.amount, 150000);

      await controller.updateItem(controller.fixed.single, 'العمال', 999);
      expect(controller.fixed.single.amount, 999);
      expect((await expenses.templates()).single.amount, 150000);

      await controller.goToNext();
      expect(controller.fixed.single.amount, 150000);
    });

    test('مجموع الشخصية الشهري يضم كل أيام الشهر', () async {
      await openToday();
      await controller.addItem(ExpenseKind.personal, 'وجبة', 4000);

      await controller.goToPrevious();
      await controller.openDay();
      await controller.addItem(ExpenseKind.personal, 'اتصالات', 2500);

      expect(controller.monthly!.count, 2);
      expect(controller.monthly!.total, 6500);
      expect(controller.totals!.general, 0);
    });
  });

  group('اليوم المقفل', () {
    test('يُعرض بنوده للقراءة فقط وكل كتابة ترفع رسالة القفل', () async {
      await openToday();
      await controller.addItem(ExpenseKind.variable, 'صيانة', 15000);
      await db.rawUpdate(
        "UPDATE days SET status = 'locked', locked_at = '2026-11-24T20:00:00Z' "
        "WHERE date = '2026-11-24'",
      );
      await controller.load();

      expect(controller.isLocked, isTrue);
      expect(names(controller.variable), ['صيانة']);

      expect(await controller.addItem(ExpenseKind.variable, 'جديد', 1), isNull);
      expect(controller.error, lockedDayMessage);
      await controller.removeItem(controller.variable.single);
      expect(controller.error, lockedDayMessage);
      expect(names(controller.variable), ['صيانة']);
      expect(controller.totals!.variable, 15000);
    });
  });

  group('الطابور', () {
    test('إضافات متتالية بلا انتظار تُنفَّذ كلها بالترتيب', () async {
      await openToday();
      final futures = <Future<String?>>[
        controller.addItem(ExpenseKind.variable, 'أ', 1),
        controller.addItem(ExpenseKind.variable, 'ب', 2),
        controller.addItem(ExpenseKind.variable, 'ج', 3),
      ];
      await Future.wait(futures);

      expect(names(controller.variable), ['أ', 'ب', 'ج']);
      expect(controller.totals!.variable, 6);
    });
  });
}
