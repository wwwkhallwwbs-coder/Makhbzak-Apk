import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:makhbazak/data/models.dart';
import 'package:makhbazak/features/expenses/expenses_controller.dart';
import 'package:makhbazak/features/expenses/expenses_screen.dart';
import 'package:makhbazak/features/production/production_controller.dart';

import 'support/fakes.dart';

const String _today = '2026-11-24';

const ValueKey<String> _nameKey = ValueKey<String>('expense-name');
const ValueKey<String> _amountKey = ValueKey<String>('expense-amount');

/// اختبارات شاشة المصروفات. المستودعات بدائل في الذاكرة (test/support)،
/// فكل شيء في الزمن المزيَّف بلا قاعدة بيانات.
void main() {
  void useTallScreen(WidgetTester tester) {
    tester.view.physicalSize = const Size(800, 3000);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
  }

  Future<void> settle(WidgetTester tester) async {
    for (var i = 0; i < 3; i++) {
      await tester.pump(const Duration(milliseconds: 300));
    }
  }

  ExpensesController buildController(FakeDays days, FakeExpenses expenses) {
    return ExpensesController(
      days: days,
      expenses: expenses,
      clock: () => DateTime(2026, 11, 24, 10),
    );
  }

  Future<void> show(WidgetTester tester, ExpensesController controller) async {
    await tester.pumpWidget(
      MaterialApp(
        home: ExpensesScreen(
          controller: controller,
          onOpenSettings: () async {},
        ),
      ),
    );
    await settle(tester);
  }

  /// نص المبلغ الذي مفتاحه [key] (المفتاح على الـ Text نفسه أو على ما يحويه).
  String amountOf(WidgetTester tester, String key) {
    final finder = find.descendant(
      of: find.byKey(ValueKey<String>(key)),
      matching: find.byType(Text),
      matchRoot: true,
    );
    return tester.widget<Text>(finder).data!;
  }

  /// يوم مفتوح بأرقام التصميم: ثابت 220,000 ومتحرك 25,000 وشخصي 12,000،
  /// وإجمالي الشهر 84,000 في 7 بنود.
  ({FakeDays days, FakeExpenses expenses}) designDay({bool locked = false}) {
    final days = FakeDays();
    final day = days.seedDay(_today, locked: locked);
    final expenses = FakeExpenses();
    expenses.seed(day.id, ExpenseKind.fixed, 'العمال', 150000);
    expenses.seed(day.id, ExpenseKind.fixed, 'النظافة', 20000);
    expenses.seed(day.id, ExpenseKind.fixed, 'أجر البنكجي', 50000);
    expenses.seed(day.id, ExpenseKind.variable, 'صيانة', 15000);
    expenses.seed(day.id, ExpenseKind.variable, 'مواصلات', 10000);
    expenses.seed(day.id, ExpenseKind.personal, 'مصروف شخصي', 12000);
    expenses.monthlyOverride = const MonthlyPersonal(count: 7, total: 84000);
    return (days: days, expenses: expenses);
  }

  FakeDays emptyOpenDay() {
    final days = FakeDays();
    days.seedDay(_today);
    return days;
  }

  testWidgets('يعرض أرقام التصميم', (tester) async {
    useTallScreen(tester);
    final setup = designDay();
    await show(tester, buildController(setup.days, setup.expenses));

    expect(find.text('المصروفات'), findsOneWidget);
    expect(find.text('مصروفات ثابتة يومية'), findsOneWidget);
    expect(find.text('مصروفات متحركة'), findsOneWidget);
    expect(find.text('مصروفات الوكيل الشخصية'), findsOneWidget);
    expect(find.text('إجمالي مصروفات البنكجي'), findsOneWidget);
    expect(find.text('تُخصم من إيراد الشباك'), findsOneWidget);

    expect(amountOf(tester, 'fixed-total'), '220,000');
    expect(amountOf(tester, 'variable-total'), '25,000');
    expect(amountOf(tester, 'bankaji-total'), '245,000');
    expect(amountOf(tester, 'personal-total'), '12,000');
    expect(amountOf(tester, 'month-total'), '84,000');
    expect(find.text('إجمالي هذا الشهر (7 بنود)'), findsOneWidget);

    for (final name in ['العمال', 'النظافة', 'أجر البنكجي', 'صيانة', 'مواصلات', 'مصروف شخصي']) {
      expect(find.text(name), findsOneWidget);
    }
    expect(find.text('إضافة بند ثابت'), findsOneWidget);
    expect(find.text('إضافة بند متحرك'), findsOneWidget);
    expect(find.text('إضافة بند للوكيل'), findsOneWidget);
  });

  testWidgets('اليوم غير المفتوح: زر فتح اليوم يفتحه', (tester) async {
    useTallScreen(tester);
    await show(tester, buildController(FakeDays(), FakeExpenses()));

    expect(find.text('لم يُفتح هذا اليوم بعد'), findsOneWidget);
    expect(find.text('مصروفات ثابتة يومية'), findsNothing);

    await tester.tap(find.text('فتح اليوم'));
    await settle(tester);

    expect(find.text('لم يُفتح هذا اليوم بعد'), findsNothing);
    expect(find.text('مصروفات ثابتة يومية'), findsOneWidget);
    expect(find.text('لا بنود ثابتة'), findsOneWidget);
    expect(amountOf(tester, 'bankaji-total'), '0');
  });

  testWidgets('إضافة بند ثابت من النافذة تظهر في القائمة والإجماليات', (tester) async {
    useTallScreen(tester);
    await show(tester, buildController(emptyOpenDay(), FakeExpenses()));

    await tester.tap(find.text('إضافة بند ثابت'));
    await settle(tester);
    expect(find.text('بند ثابت جديد'), findsOneWidget);
    expect(find.text('بند ثابت: يُنسخ إلى كل يوم جديد.'), findsOneWidget);

    await tester.enterText(find.byKey(_nameKey), 'العمال');
    await tester.enterText(find.byKey(_amountKey), '150000');
    await tester.tap(find.text('حفظ'));
    await settle(tester);

    expect(find.text('بند ثابت جديد'), findsNothing);
    expect(find.text('العمال'), findsOneWidget);
    expect(amountOf(tester, 'fixed-total'), '150,000');
    expect(amountOf(tester, 'bankaji-total'), '150,000');
  });

  testWidgets('بند شخصي يدخل إجمالي الشهر ولا يدخل إجمالي البنكجي', (tester) async {
    useTallScreen(tester);
    await show(tester, buildController(emptyOpenDay(), FakeExpenses()));

    await tester.tap(find.text('إضافة بند للوكيل'));
    await settle(tester);
    await tester.enterText(find.byKey(_nameKey), 'وجبة');
    await tester.enterText(find.byKey(_amountKey), '4000');
    await tester.tap(find.text('حفظ'));
    await settle(tester);

    expect(amountOf(tester, 'personal-total'), '4,000');
    expect(amountOf(tester, 'month-total'), '4,000');
    expect(find.text('إجمالي هذا الشهر (1 بند)'), findsOneWidget);
    expect(amountOf(tester, 'bankaji-total'), '0');
  });

  testWidgets('الاسم المكرر يُبقي النافذة مفتوحة برسالة', (tester) async {
    useTallScreen(tester);
    final setup = designDay();
    await show(tester, buildController(setup.days, setup.expenses));

    await tester.tap(find.text('إضافة بند ثابت'));
    await settle(tester);
    await tester.enterText(find.byKey(_nameKey), 'العمال');
    await tester.enterText(find.byKey(_amountKey), '1');
    await tester.tap(find.text('حفظ'));
    await settle(tester);

    expect(find.text('يوجد بند ثابت بهذا الاسم'), findsOneWidget);
    expect(find.text('بند ثابت جديد'), findsOneWidget);
    expect(amountOf(tester, 'fixed-total'), '220,000');
  });

  testWidgets('اسم فارغ ومبلغ غير رقم يرفعان رسالة داخل النافذة', (tester) async {
    useTallScreen(tester);
    await show(tester, buildController(emptyOpenDay(), FakeExpenses()));

    await tester.tap(find.text('إضافة بند متحرك'));
    await settle(tester);

    // المبلغ فارغ.
    await tester.enterText(find.byKey(_nameKey), 'صيانة');
    await tester.tap(find.text('حفظ'));
    await settle(tester);
    expect(find.text('اكتب المبلغ بالأرقام'), findsOneWidget);

    // الاسم فارغ.
    await tester.enterText(find.byKey(_nameKey), '');
    await tester.enterText(find.byKey(_amountKey), '500');
    await tester.tap(find.text('حفظ'));
    await settle(tester);
    expect(find.text('اكتب اسم البند'), findsOneWidget);
    expect(find.text('بند متحرك جديد'), findsOneWidget);
  });

  testWidgets('تعديل بند ثم حذفه بخطوتين', (tester) async {
    useTallScreen(tester);
    final setup = designDay();
    await show(tester, buildController(setup.days, setup.expenses));

    await tester.tap(find.text('النظافة'));
    await settle(tester);
    expect(find.text('تعديل البند'), findsOneWidget);
    expect(tester.widget<TextField>(find.byKey(_amountKey)).controller!.text, '20000');

    await tester.enterText(find.byKey(_amountKey), '25000');
    await tester.tap(find.text('حفظ'));
    await settle(tester);
    expect(find.text('تعديل البند'), findsNothing);
    expect(amountOf(tester, 'fixed-total'), '225,000');

    await tester.tap(find.text('النظافة'));
    await settle(tester);
    await tester.tap(find.text('حذف'));
    await settle(tester);
    // الخطوة الأولى لا تحذف: يظهر التأكيد فقط.
    expect(find.text('تأكيد الحذف'), findsOneWidget);
    expect(find.text('تعديل البند'), findsOneWidget);

    await tester.tap(find.text('تأكيد الحذف'));
    await settle(tester);
    expect(find.text('النظافة'), findsNothing);
    expect(amountOf(tester, 'fixed-total'), '200,000');
    expect(amountOf(tester, 'bankaji-total'), '225,000');
  });

  testWidgets('اليوم المقفل: للقراءة فقط بلا أزرار إضافة ولا نوافذ', (tester) async {
    useTallScreen(tester);
    final setup = designDay(locked: true);
    await show(tester, buildController(setup.days, setup.expenses));

    expect(find.text(lockedDayMessage), findsOneWidget);
    expect(find.text('إضافة بند ثابت'), findsNothing);
    expect(find.text('إضافة بند متحرك'), findsNothing);
    expect(find.text('إضافة بند للوكيل'), findsNothing);
    expect(amountOf(tester, 'bankaji-total'), '245,000');

    await tester.tap(find.text('العمال'));
    await settle(tester);
    expect(find.byType(AlertDialog), findsNothing);
  });

  testWidgets('في يوم سابق تنبّه النافذة أن الثابت يخص ذلك اليوم وحده', (tester) async {
    useTallScreen(tester);
    final setup = designDay();
    await show(tester, buildController(setup.days, setup.expenses));

    await tester.tap(find.byTooltip('اليوم السابق'));
    await settle(tester);
    await tester.tap(find.text('فتح اليوم'));
    await settle(tester);

    await tester.tap(find.text('إضافة بند ثابت'));
    await settle(tester);
    expect(find.text('تغيير في يوم سابق: يخص هذا اليوم وحده.'), findsOneWidget);
  });
}
