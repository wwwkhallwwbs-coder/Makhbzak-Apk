import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:makhbazak/core/accounting.dart';
import 'package:makhbazak/data/app_database.dart';
import 'package:makhbazak/data/day_repository.dart';
import 'package:makhbazak/data/device_repository.dart';
import 'package:makhbazak/data/distribution_repository.dart';
import 'package:makhbazak/data/models.dart';
import 'package:makhbazak/data/settings_repository.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  sqfliteFfiInit();

  late Database db;
  late DeviceInfo device;
  late DayRepository days;
  late DistributionRepository distribution;
  late SettingsRepository settings;
  late String schemaSql;

  setUpAll(() {
    schemaSql = File('assets/db/schema.sql').readAsStringSync();
  });

  setUp(() async {
    db = await openAppDatabase(
      schemaSql: schemaSql,
      path: inMemoryDatabasePath,
      factory: databaseFactoryFfi,
    );
    device = await DeviceRepository(db).activateAsAgent(
      codeHash: 'a' * 64,
      bakeryName: 'مخبز التجربة',
      agentName: 'وكيل التجربة',
      startedAt: '2026-01-01',
    );
    settings = SettingsRepository(
      db,
      bakeryId: device.bakeryId!,
      deviceId: device.id,
    );
    days = DayRepository(
      db,
      bakeryId: device.bakeryId!,
      agentId: device.agentId!,
      deviceId: device.id,
    );
    distribution = DistributionRepository(
      db,
      bakeryId: device.bakeryId!,
      deviceId: device.id,
    );
    await settings.set(SettingKeys.windowPrice, 100);
    await settings.set(SettingKeys.distributionPrice, 90);
  });

  tearDown(() async {
    await db.close();
  });

  Future<DayRecord> openDay([String date = '2026-11-21']) => days.getOrCreate(date);

  group('الموزعون', () {
    test('الإضافة بلا اسم تعطي أسماء مبدئية متتابعة', () async {
      final first = await distribution.addDistributor();
      final second = await distribution.addDistributor();
      final third = await distribution.addDistributor();

      expect(first.name, 'الموزع الأول');
      expect(second.name, 'الموزع الثاني');
      expect(third.name, 'الموزع الثالث');
      final all = await distribution.distributors();
      expect(all.map((e) => e.name).toList(), [
        'الموزع الأول',
        'الموزع الثاني',
        'الموزع الثالث',
      ]);
    });

    test('الاسم المبدئي يتخطى المستعمل بعد إعادة التسمية', () async {
      final first = await distribution.addDistributor();
      await distribution.renameDistributor(first.id, 'مطعم النيل');
      final next = await distribution.addDistributor();

      // «الموزع الأول» صار حراً فيُعاد استعماله.
      expect(next.name, 'الموزع الأول');
    });

    test('إضافة باسم صريح، وتنظيف المسافات، ورفض الفارغ والمكرر', () async {
      final added = await distribution.addDistributor('  كافتيريا   الجامعة ');
      expect(added.name, 'كافتيريا الجامعة');

      await expectLater(distribution.addDistributor('   '), throwsArgumentError);
      await expectLater(
        distribution.addDistributor('كافتيريا الجامعة'),
        throwsStateError,
      );
      await expectLater(
        distribution.addDistributor('ا' * (maxDistributorNameLength + 1)),
        throwsArgumentError,
      );
    });

    test('إعادة التسمية تغيّر الاسم وترفض اسماً مستعملاً', () async {
      final a = await distribution.addDistributor('أحمد');
      final b = await distribution.addDistributor('بشير');

      await distribution.renameDistributor(a.id, 'أحمد علي');
      final names = (await distribution.distributors()).map((e) => e.name).toList();
      expect(names, ['أحمد علي', 'بشير']);

      await expectLater(
        distribution.renameDistributor(b.id, 'أحمد علي'),
        throwsStateError,
      );
      // إعادة تسمية الموزع باسمه نفسه ليست تكراراً.
      await distribution.renameDistributor(b.id, 'بشير');
    });
  });

  group('تسجيل اليوم', () {
    test('اليوم المفتوح يعرض كل الموزعين بصفر قبل أي تسجيل', () async {
      final day = await openDay();
      await distribution.addDistributor();
      await distribution.addDistributor();

      final rows = await distribution.rowsForDay(day.id, onlyWithEntries: false);
      expect(rows.length, 2);
      expect(rows.every((row) => row.loaves == 0 && row.paid == 0), isTrue);
      expect(await db.query('distributions'), isEmpty);
    });

    test('الكمية والمسدد: إضافة ثم تعديل بلا صف مكرر', () async {
      final day = await openDay();
      final p = await distribution.addDistributor();

      await distribution.setLoaves(day.id, p.id, 250);
      await distribution.setPaid(day.id, p.id, 20000);
      await distribution.setLoaves(day.id, p.id, 300);

      final rows = await distribution.rowsForDay(day.id, onlyWithEntries: false);
      expect(rows.single.loaves, 300);
      expect(rows.single.paid, 20000);
      expect((await db.query('distributions')).length, 1);
    });

    test('تسجيل المسدد وحده ينشئ صفاً بكمية صفر (سداد دين سابق)', () async {
      final day = await openDay();
      final p = await distribution.addDistributor();
      await distribution.setPaid(day.id, p.id, 7000);

      final row = (await distribution.rowsForDay(day.id, onlyWithEntries: false)).single;
      expect(row.loaves, 0);
      expect(row.paid, 7000);
    });

    test('الأرقام السالبة تُرفض قبل القاعدة', () async {
      final day = await openDay();
      final p = await distribution.addDistributor();
      await expectLater(distribution.setLoaves(day.id, p.id, -1), throwsArgumentError);
      await expectLater(distribution.setPaid(day.id, p.id, -5), throwsArgumentError);
    });

    test('كل يوم له أرقامه لنفس الموزع', () async {
      final d1 = await openDay('2026-11-20');
      final d2 = await openDay('2026-11-21');
      final p = await distribution.addDistributor();
      await distribution.setLoaves(d1.id, p.id, 100);
      await distribution.setLoaves(d2.id, p.id, 200);

      expect(
        (await distribution.rowsForDay(d1.id, onlyWithEntries: false)).single.loaves,
        100,
      );
      expect(
        (await distribution.rowsForDay(d2.id, onlyWithEntries: false)).single.loaves,
        200,
      );
    });
  });

  group('أرقام المواصفة §4.2', () {
    test('730 موزَّعة، مستحق 65,700، مسدد 52,500، متبقٍ 13,200، وشباك 8,310 بإيراد 831,000', () async {
      final day = await openDay();
      final a = await distribution.addDistributor();
      final b = await distribution.addDistributor();
      final c = await distribution.addDistributor();
      await distribution.setLoaves(day.id, a.id, 250);
      await distribution.setPaid(day.id, a.id, 22500);
      await distribution.setLoaves(day.id, b.id, 300);
      await distribution.setPaid(day.id, b.id, 20000);
      await distribution.setLoaves(day.id, c.id, 180);
      await distribution.setPaid(day.id, c.id, 10000);

      final rows = await distribution.rowsForDay(day.id, onlyWithEntries: false);
      final lines = rows
          .map(
            (row) => DistributorLine(
              name: row.name,
              loaves: row.loaves,
              paid: row.paid,
              distributionPrice: day.distributionPrice,
            ),
          )
          .toList();
      expect(lines.map((l) => l.remaining).toList(), [0, 7000, 6200]);

      final totals = totalDistribution(lines);
      expect(totals.loaves, 730);
      expect(totals.due, 65700);
      expect(totals.paid, 52500);
      expect(totals.remaining, 13200);

      final window = computeWindowAccount(
        totalLoaves: 9040,
        distributedLoaves: totals.loaves,
        windowPrice: day.windowPrice,
      );
      expect(window.windowLoaves, 8310);
      expect(window.windowRevenue, 831000);

      // المشهد في القاعدة يعطي المتبقي نفسه.
      final view = await db.query(
        'v_distribution_lines',
        columns: ['remaining'],
        where: 'day_id = ?',
        whereArgs: [day.id],
        orderBy: 'remaining',
      );
      expect(view.map((r) => r['remaining']).toList(), [0, 6200, 7000]);
    });
  });

  group('اليوم المقفل', () {
    Future<void> lock(String dayId) async {
      await db.rawUpdate(
        "UPDATE days SET status = 'locked', locked_at = '2026-11-21T20:00:00Z' WHERE id = ?",
        [dayId],
      );
    }

    test('الكتابة عليه مرفوضة من القاعدة (إضافة وتعديل)', () async {
      final day = await openDay();
      final p = await distribution.addDistributor();
      final q = await distribution.addDistributor();
      await distribution.setLoaves(day.id, p.id, 250);
      await lock(day.id);

      await expectLater(
        distribution.setLoaves(day.id, p.id, 999),
        throwsA(isA<DatabaseException>()),
      );
      await expectLater(
        distribution.setPaid(day.id, q.id, 100),
        throwsA(isA<DatabaseException>()),
      );
      final rows = await distribution.rowsForDay(day.id, onlyWithEntries: true);
      expect(rows.single.loaves, 250);
    });

    test('عرض اليوم المقفل لا يشمل إلا من سُجّل له شيء', () async {
      final day = await openDay();
      final p = await distribution.addDistributor();
      await distribution.addDistributor();
      await distribution.setLoaves(day.id, p.id, 250);
      await lock(day.id);
      // موزع يُضاف بعد القفل لا يظهر في اليوم المقفل.
      await distribution.addDistributor();

      final locked = await distribution.rowsForDay(day.id, onlyWithEntries: true);
      expect(locked.length, 1);
      expect(locked.single.name, 'الموزع الأول');
    });

    test('تعديل أسعار اليوم المقفل مرفوض، والمفتوح يقبل', () async {
      final open = await openDay('2026-11-20');
      await days.updatePrices(open.id, windowPrice: 110, distributionPrice: 95);
      final changed = await days.find('2026-11-20');
      expect(changed!.windowPrice, 110);
      expect(changed.distributionPrice, 95);

      final other = await openDay('2026-11-21');
      await lock(other.id);
      await expectLater(
        days.updatePrices(other.id, windowPrice: 150),
        throwsA(isA<DatabaseException>()),
      );
      expect((await days.find('2026-11-21'))!.windowPrice, 100);
    });

    test('سعر سالب يُرفض ولا تغيير بلا قيم', () async {
      final day = await openDay();
      await expectLater(days.updatePrices(day.id, windowPrice: -1), throwsArgumentError);
      await days.updatePrices(day.id);
      expect((await days.find('2026-11-21'))!.windowPrice, 100);
    });
  });
}
