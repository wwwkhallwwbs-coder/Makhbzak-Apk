import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:makhbazak/core/accounting.dart';
import 'package:makhbazak/data/app_database.dart';
import 'package:makhbazak/data/day_repository.dart';
import 'package:makhbazak/data/device_repository.dart';
import 'package:makhbazak/data/expense_repository.dart';
import 'package:makhbazak/data/models.dart';
import 'package:makhbazak/data/settings_repository.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  sqfliteFfiInit();

  late Database db;
  late DayRepository days;
  late ExpenseRepository expenses;
  late String schemaSql;

  setUpAll(() {
    schemaSql = File('assets/db/schema.sql').readAsStringSync();
  });

  setUp(() async {
    db = await openAppDatabase(
      schemaSql: schemaSql,
      path: inMemoryDatabasePath,
      factory: databaseFactoryFfi,
    );
    final device = await DeviceRepository(db).activateAsAgent(
      codeHash: 'a' * 64,
      bakeryName: 'مخبز التجربة',
      agentName: 'وكيل التجربة',
      startedAt: '2026-01-01',
    );
    final settings = SettingsRepository(
      db,
      bakeryId: device.bakeryId!,
      deviceId: device.id,
    );
    days = DayRepository(
      db,
      bakeryId: device.bakeryId!,
      agentId: device.agentId!,
      deviceId: device.id,
    );
    expenses = ExpenseRepository(
      db,
      bakeryId: device.bakeryId!,
      agentId: device.agentId!,
      deviceId: device.id,
    );
    await settings.set(SettingKeys.windowPrice, 100);
    await settings.set(SettingKeys.distributionPrice, 90);
  });

  tearDown(() async {
    await db.close();
  });

  Future<DayRecord> openDay([String date = '2026-11-21']) => days.getOrCreate(date);

  Future<void> lock(String dayId) async {
    await db.rawUpdate(
      "UPDATE days SET status = 'locked', locked_at = '2026-11-21T20:00:00Z' WHERE id = ?",
      [dayId],
    );
  }

  List<String> names(List<ExpenseRow> rows) => rows.map((e) => e.name).toList();

  group('الإضافة والعرض', () {
    test('الأنواع الثلاثة تُحفظ وتُقرأ بنوعها وبترتيب الإضافة', () async {
      final day = await openDay();
      await expenses.add(day.id, ExpenseKind.fixed, 'العمال', 150000);
      await expenses.add(day.id, ExpenseKind.variable, 'صيانة', 15000);
      await expenses.add(day.id, ExpenseKind.personal, 'مصروف شخصي', 12000);

      final rows = await expenses.forDay(day.id);
      expect(names(rows), ['العمال', 'صيانة', 'مصروف شخصي']);
      expect(rows.map((e) => e.kind).toList(), [
        ExpenseKind.fixed,
        ExpenseKind.variable,
        ExpenseKind.personal,
      ]);
      expect(rows.map((e) => e.amount).toList(), [150000, 15000, 12000]);
    });

    test('تنظيف المسافات، ورفض الاسم الفارغ والطويل والمبلغ السالب', () async {
      final day = await openDay();
      final row = await expenses.add(day.id, ExpenseKind.variable, '  نقل   بضاعة ', 500);
      expect(row.name, 'نقل بضاعة');

      await expectLater(
        expenses.add(day.id, ExpenseKind.variable, '   ', 1),
        throwsArgumentError,
      );
      await expectLater(
        expenses.add(day.id, ExpenseKind.variable, 'ا' * (maxExpenseNameLength + 1), 1),
        throwsArgumentError,
      );
      await expectLater(
        expenses.add(day.id, ExpenseKind.variable, 'خصم', -1),
        throwsArgumentError,
      );
      await expectLater(expenses.update(row.id, 'نقل', -5), throwsArgumentError);
    });

    test('البند الثابت لا يتكرر اسمه في اليوم، والمتحرك والشخصي يتكرران', () async {
      final day = await openDay();
      await expenses.add(day.id, ExpenseKind.fixed, 'النظافة', 20000);
      await expectLater(
        expenses.add(day.id, ExpenseKind.fixed, 'النظافة', 1),
        throwsStateError,
      );
      await expenses.add(day.id, ExpenseKind.variable, 'مواصلات', 5000);
      await expenses.add(day.id, ExpenseKind.variable, 'مواصلات', 5000);
      await expenses.add(day.id, ExpenseKind.personal, 'وجبة', 3000);
      await expenses.add(day.id, ExpenseKind.personal, 'وجبة', 3000);
      expect((await expenses.forDay(day.id)).length, 5);
    });

    test('التعديل يغيّر الاسم والمبلغ، والإلغاء يُخرج البند ويبقيه في السجل', () async {
      final day = await openDay();
      final a = await expenses.add(day.id, ExpenseKind.variable, 'صيانة', 15000);
      final b = await expenses.add(day.id, ExpenseKind.variable, 'مواصلات', 10000);

      await expenses.update(a.id, 'صيانة الفرن', 18000);
      await expenses.cancel(b.id);

      final rows = await expenses.forDay(day.id);
      expect(rows.single.name, 'صيانة الفرن');
      expect(rows.single.amount, 18000);
      expect((await db.query('expenses')).length, 2);
      await expectLater(expenses.cancel(b.id), throwsStateError);
      await expectLater(expenses.update(b.id, 'س', 1), throwsStateError);
    });

    test('تعديل بند ثابت إلى اسم بند ثابت آخر في اليوم مرفوض', () async {
      final day = await openDay();
      await expenses.add(day.id, ExpenseKind.fixed, 'العمال', 1);
      final cleaning = await expenses.add(day.id, ExpenseKind.fixed, 'النظافة', 2);
      await expectLater(
        expenses.update(cleaning.id, 'العمال', 2),
        throwsStateError,
      );
      // بقاء الاسم نفسه ليس تكراراً.
      await expenses.update(cleaning.id, 'النظافة', 3);
    });
  });

  group('القوالب: الثوابت تنتقل إلى الأيام الجديدة', () {
    test('يوم بلا قوالب يُفتح بلا مصروفات', () async {
      final day = await openDay();
      expect(await expenses.forDay(day.id), isEmpty);
    });

    test('إضافة ثابت اليوم الحالي (مع القالب) تظهر في اليوم التالي بمبلغها', () async {
      final today = await openDay('2026-11-21');
      await expenses.add(today.id, ExpenseKind.fixed, 'العمال', 150000, syncTemplate: true);
      await expenses.add(today.id, ExpenseKind.fixed, 'النظافة', 20000, syncTemplate: true);
      await expenses.add(today.id, ExpenseKind.variable, 'صيانة', 15000, syncTemplate: true);

      final next = await openDay('2026-11-22');
      final rows = await expenses.forDay(next.id);
      expect(names(rows), ['العمال', 'النظافة']);
      expect(rows.map((e) => e.amount).toList(), [150000, 20000]);
      expect(rows.every((e) => e.kind == ExpenseKind.fixed), isTrue);
    });

    test('إضافة ثابت بلا syncTemplate (يوم سابق) لا تنتقل للأيام الجديدة', () async {
      final past = await openDay('2026-11-10');
      await expenses.add(past.id, ExpenseKind.fixed, 'عمل استثنائي', 1000);

      final next = await openDay('2026-11-11');
      expect(await expenses.forDay(next.id), isEmpty);
      expect(await expenses.templates(), isEmpty);
    });

    test('تعديل مبلغ ثابت اليوم الحالي يغيّر قالبه، ولا يغيّر الأيام الفعلية السابقة', () async {
      final d1 = await openDay('2026-11-20');
      await expenses.add(d1.id, ExpenseKind.fixed, 'العمال', 150000, syncTemplate: true);
      final d2 = await openDay('2026-11-21');
      final d2Row = (await expenses.forDay(d2.id)).single;

      await expenses.update(d2Row.id, 'العمال', 160000, syncTemplate: true);

      expect((await expenses.forDay(d1.id)).single.amount, 150000);
      expect((await expenses.forDay(d2.id)).single.amount, 160000);
      final d3 = await openDay('2026-11-22');
      expect((await expenses.forDay(d3.id)).single.amount, 160000);
      expect((await expenses.templates()).single.amount, 160000);
    });

    test('تعديل ثابت في يوم سابق (بلا syncTemplate) لا يمسّ القالب', () async {
      final d1 = await openDay('2026-11-20');
      await expenses.add(d1.id, ExpenseKind.fixed, 'العمال', 150000, syncTemplate: true);
      final row = (await expenses.forDay(d1.id)).single;

      await expenses.update(row.id, 'العمال', 99);

      expect((await expenses.templates()).single.amount, 150000);
      final d2 = await openDay('2026-11-21');
      expect((await expenses.forDay(d2.id)).single.amount, 150000);
    });

    test('إعادة تسمية ثابت اليوم الحالي تنقل الاسم الجديد إلى القالب', () async {
      final d1 = await openDay('2026-11-20');
      await expenses.add(d1.id, ExpenseKind.fixed, 'أجر البنكجي', 50000, syncTemplate: true);
      final row = (await expenses.forDay(d1.id)).single;

      await expenses.update(row.id, 'أجر البنكجي الجديد', 52000, syncTemplate: true);

      final template = (await expenses.templates()).single;
      expect(template.name, 'أجر البنكجي الجديد');
      expect(template.amount, 52000);
    });

    test('حذف ثابت اليوم الحالي (مع القالب) لا يعود في الأيام القادمة', () async {
      final d1 = await openDay('2026-11-20');
      await expenses.add(d1.id, ExpenseKind.fixed, 'العمال', 150000, syncTemplate: true);
      await expenses.add(d1.id, ExpenseKind.fixed, 'النظافة', 20000, syncTemplate: true);
      final cleaning = (await expenses.forDay(d1.id)).last;

      await expenses.cancel(cleaning.id, syncTemplate: true);

      expect(names(await expenses.templates()), ['العمال']);
      final d2 = await openDay('2026-11-21');
      expect(names(await expenses.forDay(d2.id)), ['العمال']);
    });

    test('حذف ثابت يوم سابق (بلا syncTemplate) يبقي القالب', () async {
      final d1 = await openDay('2026-11-20');
      await expenses.add(d1.id, ExpenseKind.fixed, 'العمال', 150000, syncTemplate: true);
      final row = (await expenses.forDay(d1.id)).single;

      await expenses.cancel(row.id);

      expect(names(await expenses.templates()), ['العمال']);
    });

    test('إضافة ثابت باسم قالب موجود تحدّث القالب ولا تكرره', () async {
      final d1 = await openDay('2026-11-20');
      await expenses.add(d1.id, ExpenseKind.fixed, 'العمال', 100, syncTemplate: true);
      final d2 = await openDay('2026-11-21');
      final inherited = (await expenses.forDay(d2.id)).single;
      await expenses.cancel(inherited.id);
      await expenses.add(d2.id, ExpenseKind.fixed, 'العمال', 200, syncTemplate: true);

      final templates = await expenses.templates();
      expect(templates.length, 1);
      expect(templates.single.amount, 200);
    });
  });

  group('مصروفات الوكيل الشخصية الشهرية', () {
    test('تجمع كل أيام الشهر وتستثني العامة والملغاة والأشهر الأخرى', () async {
      final a = await openDay('2026-11-03');
      final b = await openDay('2026-11-20');
      final other = await openDay('2026-10-30');
      await expenses.add(a.id, ExpenseKind.personal, 'وجبة', 1000);
      await expenses.add(a.id, ExpenseKind.personal, 'اتصالات', 2000);
      final cancelled = await expenses.add(b.id, ExpenseKind.personal, 'خطأ', 7777);
      await expenses.cancel(cancelled.id);
      await expenses.add(b.id, ExpenseKind.personal, 'مواصلات', 3000);
      await expenses.add(b.id, ExpenseKind.variable, 'صيانة', 50000);
      await expenses.add(other.id, ExpenseKind.personal, 'الشهر الماضي', 9000);

      final month = await expenses.monthlyPersonal('2026-11-20');
      expect(month.count, 3);
      expect(month.total, 6000);

      final before = await expenses.monthlyPersonal('2026-10-05');
      expect(before.count, 1);
      expect(before.total, 9000);
    });

    test('شهر بلا بنود يعطي صفراً', () async {
      final month = await expenses.monthlyPersonal('2026-11-21');
      expect(month.count, 0);
      expect(month.total, 0);
    });

    test('اليوم المقفل يدخل في إجمالي الشهر', () async {
      final day = await openDay('2026-11-05');
      await expenses.add(day.id, ExpenseKind.personal, 'وجبة', 4000);
      await lock(day.id);
      final month = await expenses.monthlyPersonal('2026-11-21');
      expect(month.total, 4000);
    });
  });

  group('الإجمالي (أرقام التصميم)', () {
    test('ثابت 220,000 + متحرك 25,000 = 245,000 تُخصم من إيراد الشباك', () {
      final totals = summarizeExpenses(
        fixed: [150000, 20000, 50000],
        variable: [15000, 10000],
      );
      expect(totals.fixed, 220000);
      expect(totals.variable, 25000);
      expect(totals.general, 245000);
    });

    test('قائمة فارغة تعطي صفراً', () {
      final totals = summarizeExpenses(fixed: const [], variable: const []);
      expect(totals.general, 0);
    });
  });

  group('اليوم المقفل', () {
    test('الإضافة والتعديل والإلغاء مرفوضة من القاعدة', () async {
      final day = await openDay();
      final row = await expenses.add(day.id, ExpenseKind.variable, 'صيانة', 100);
      await lock(day.id);

      await expectLater(
        expenses.add(day.id, ExpenseKind.variable, 'جديد', 1),
        throwsA(isA<DatabaseException>()),
      );
      await expectLater(
        expenses.update(row.id, 'صيانة', 999),
        throwsA(isA<DatabaseException>()),
      );
      await expectLater(
        expenses.cancel(row.id),
        throwsA(isA<DatabaseException>()),
      );
      final rows = await expenses.forDay(day.id);
      expect(rows.single.amount, 100);
    });
  });
}
