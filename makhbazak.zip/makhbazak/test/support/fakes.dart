import 'package:flutter_test/flutter_test.dart';
import 'package:makhbazak/core/labels_ar.dart';
import 'package:makhbazak/data/day_repository.dart';
import 'package:makhbazak/data/distribution_repository.dart';
import 'package:makhbazak/data/expense_repository.dart';
import 'package:makhbazak/data/models.dart';
import 'package:makhbazak/data/settings_repository.dart';
import 'package:sqflite/sqflite.dart';

/// بدائل المستودعات لاختبارات الواجهة: كل شيء في الذاكرة وبلا قاعدة بيانات،
/// فيعمل داخل الزمن المزيَّف لاختبارات الواجهة بلا أي دخل/خرج فعلي.
/// (القاعدة الحقيقية تُختبر في test/data وفي اختبارات المتحكمات.)
///
/// دوال `seed…` متزامنة لتجهيز الحالة قبل عرض الشاشة.

/// قاعدة وهمية: أي استعمال لها خطأ في الاختبار (البدائل لا تلمسها).
class _NoDatabase extends Fake implements Database {}

class FakeDays extends DayRepository {
  FakeDays({
    this.start = '2026-11-01',
    this.hasSettings = true,
    this.windowPrice = 100,
    this.distributionPrice = 90,
    this.targetPerSack = 900,
  }) : super(
          _NoDatabase(),
          bakeryId: 'bakery',
          agentId: 'agent',
          deviceId: 'device',
        );

  final String start;
  bool hasSettings;
  final int windowPrice;
  final int distributionPrice;
  final int targetPerSack;

  final Map<String, DayRecord> _byDate = <String, DayRecord>{};
  final Map<String, Map<int, int>> _sacksOfDay = <String, Map<int, int>>{};
  int _next = 0;

  /// ينشئ يوماً (مفتوحاً أو مقفلاً) بقطعيات الجوالات [loaves] بالترتيب.
  DayRecord seedDay(
    String date, {
    List<int> loaves = const <int>[],
    bool locked = false,
  }) {
    final record = DayRecord(
      id: 'day-${_next++}',
      date: date,
      status: locked ? 'locked' : 'open',
      windowPrice: windowPrice,
      distributionPrice: distributionPrice,
      targetPerSack: targetPerSack,
      batchSizeKg: 50,
    );
    _byDate[date] = record;
    final entries = <int, int>{};
    for (var i = 0; i < loaves.length; i++) {
      entries[i + 1] = loaves[i];
    }
    _sacksOfDay[record.id] = entries;
    return record;
  }

  @override
  Future<DayRecord?> find(String date) async => _byDate[date];

  @override
  Future<DayRecord> getOrCreate(String date) async => _byDate[date] ?? seedDay(date);

  @override
  Future<void> updatePrices(
    String dayId, {
    int? windowPrice,
    int? distributionPrice,
  }) async {
    for (final entry in _byDate.entries.toList()) {
      final old = entry.value;
      if (old.id != dayId) {
        continue;
      }
      if (old.isLocked) {
        throw StateError('day is locked');
      }
      _byDate[entry.key] = DayRecord(
        id: old.id,
        date: old.date,
        status: old.status,
        windowPrice: windowPrice ?? old.windowPrice,
        distributionPrice: distributionPrice ?? old.distributionPrice,
        targetPerSack: old.targetPerSack,
        batchSizeKg: old.batchSizeKg,
      );
    }
  }

  @override
  Future<bool> hasOpeningSettings() async => hasSettings;

  @override
  Future<String?> agentStartDate() async => start;

  @override
  Future<void> setSack(String dayId, int seq, int loaves) async {
    _sacksOfDay.putIfAbsent(dayId, () => <int, int>{})[seq] = loaves;
  }

  @override
  Future<void> cancelSack(String dayId, int seq) async {
    _sacksOfDay[dayId]?.remove(seq);
  }

  @override
  Future<List<SackEntry>> sacks(String dayId) async {
    final entries = _sacksOfDay[dayId] ?? const <int, int>{};
    final seqs = entries.keys.toList()..sort();
    return <SackEntry>[
      for (final seq in seqs) SackEntry(seq: seq, loaves: entries[seq]!),
    ];
  }
}

class FakeSettings extends SettingsRepository {
  FakeSettings() : super(_NoDatabase(), bakeryId: 'bakery', deviceId: 'device');

  /// ما كُتب في الإعدادات (المفتاح ← القيمة).
  final Map<String, Object> saved = <String, Object>{};

  @override
  Future<void> set(String key, Object value) async {
    saved[key] = value;
  }
}

class FakeDistribution extends DistributionRepository {
  FakeDistribution()
      : super(_NoDatabase(), bakeryId: 'bakery', deviceId: 'device');

  final List<DistributorInfo> _people = <DistributorInfo>[];
  final Map<String, Map<String, int>> _loaves = <String, Map<String, int>>{};
  final Map<String, Map<String, int>> _paid = <String, Map<String, int>>{};
  int _next = 0;

  /// يضيف موزعاً باسمه (دون فحص).
  DistributorInfo seed(String name) {
    final info = DistributorInfo(id: 'dist-${_next++}', name: name);
    _people.add(info);
    return info;
  }

  void seedLoaves(String dayId, String distributorId, int loaves) {
    _loaves.putIfAbsent(dayId, () => <String, int>{})[distributorId] = loaves;
  }

  void seedPaid(String dayId, String distributorId, int paid) {
    _paid.putIfAbsent(dayId, () => <String, int>{})[distributorId] = paid;
  }

  bool _taken(String name, {String? exceptId}) =>
      _people.any((p) => p.name == name && p.id != exceptId);

  String _nextDefaultName() {
    var n = 1;
    while (_taken(defaultDistributorName(n))) {
      n++;
    }
    return defaultDistributorName(n);
  }

  @override
  Future<List<DistributorInfo>> distributors() async =>
      List<DistributorInfo>.of(_people);

  @override
  Future<DistributorInfo> addDistributor([String? name]) async {
    final String wanted = name == null ? _nextDefaultName() : name.trim();
    if (wanted.isEmpty) {
      throw ArgumentError('اكتب اسم الموزع');
    }
    if (_taken(wanted)) {
      throw StateError('يوجد موزع بهذا الاسم');
    }
    return seed(wanted);
  }

  @override
  Future<void> renameDistributor(String id, String name) async {
    final wanted = name.trim();
    if (wanted.isEmpty) {
      throw ArgumentError('اكتب اسم الموزع');
    }
    if (_taken(wanted, exceptId: id)) {
      throw StateError('يوجد موزع بهذا الاسم');
    }
    final index = _people.indexWhere((p) => p.id == id);
    if (index >= 0) {
      _people[index] = DistributorInfo(id: id, name: wanted);
    }
  }

  @override
  Future<List<DistributionRow>> rowsForDay(
    String dayId, {
    required bool onlyWithEntries,
  }) async {
    final loaves = _loaves[dayId] ?? const <String, int>{};
    final paid = _paid[dayId] ?? const <String, int>{};
    return <DistributionRow>[
      for (final p in _people)
        if (!onlyWithEntries || loaves.containsKey(p.id) || paid.containsKey(p.id))
          DistributionRow(
            distributorId: p.id,
            name: p.name,
            loaves: loaves[p.id] ?? 0,
            paid: paid[p.id] ?? 0,
          ),
    ];
  }

  @override
  Future<void> setLoaves(String dayId, String distributorId, int loaves) async {
    if (loaves < 0) {
      throw ArgumentError.value(loaves, 'loaves', 'الكمية لا تكون سالبة');
    }
    seedLoaves(dayId, distributorId, loaves);
  }

  @override
  Future<void> setPaid(String dayId, String distributorId, int paid) async {
    if (paid < 0) {
      throw ArgumentError.value(paid, 'paid', 'المبلغ لا يكون سالباً');
    }
    seedPaid(dayId, distributorId, paid);
  }
}

class FakeExpenses extends ExpenseRepository {
  FakeExpenses()
      : super(
          _NoDatabase(),
          bakeryId: 'bakery',
          agentId: 'agent',
          deviceId: 'device',
        );

  final Map<String, List<ExpenseRow>> _byDay = <String, List<ExpenseRow>>{};
  int _next = 0;

  /// إجمالي الشهر الشخصي المعروض. الافتراضي: يُحسب من بنود كل الأيام المزروعة.
  MonthlyPersonal? monthlyOverride;

  /// يضيف بنداً لليوم (دون فحص).
  ExpenseRow seed(String dayId, ExpenseKind kind, String name, int amount) {
    final row = ExpenseRow(id: 'exp-${_next++}', kind: kind, name: name, amount: amount);
    _byDay.putIfAbsent(dayId, () => <ExpenseRow>[]).add(row);
    return row;
  }

  bool _fixedTaken(String dayId, String name, {String? exceptId}) =>
      (_byDay[dayId] ?? const <ExpenseRow>[]).any(
        (row) => row.kind == ExpenseKind.fixed && row.name == name && row.id != exceptId,
      );

  String _clean(String name) {
    final cleaned = name.trim();
    if (cleaned.isEmpty) {
      throw ArgumentError('اكتب اسم البند');
    }
    return cleaned;
  }

  @override
  Future<List<ExpenseRow>> forDay(String dayId) async =>
      List<ExpenseRow>.of(_byDay[dayId] ?? const <ExpenseRow>[]);

  @override
  Future<List<ExpenseRow>> templates() async => const <ExpenseRow>[];

  @override
  Future<ExpenseRow> add(
    String dayId,
    ExpenseKind kind,
    String name,
    int amount, {
    bool syncTemplate = false,
  }) async {
    final cleaned = _clean(name);
    if (amount < 0) {
      throw ArgumentError('المبلغ لا يكون سالباً');
    }
    if (kind == ExpenseKind.fixed && _fixedTaken(dayId, cleaned)) {
      throw StateError('يوجد بند ثابت بهذا الاسم');
    }
    return seed(dayId, kind, cleaned, amount);
  }

  @override
  Future<void> update(
    String id,
    String name,
    int amount, {
    bool syncTemplate = false,
  }) async {
    final cleaned = _clean(name);
    if (amount < 0) {
      throw ArgumentError('المبلغ لا يكون سالباً');
    }
    for (final entry in _byDay.entries) {
      final index = entry.value.indexWhere((row) => row.id == id);
      if (index < 0) {
        continue;
      }
      final old = entry.value[index];
      if (old.kind == ExpenseKind.fixed && _fixedTaken(entry.key, cleaned, exceptId: id)) {
        throw StateError('يوجد بند ثابت بهذا الاسم');
      }
      entry.value[index] = ExpenseRow(id: id, kind: old.kind, name: cleaned, amount: amount);
      return;
    }
    throw StateError('البند غير موجود');
  }

  @override
  Future<void> cancel(String id, {bool syncTemplate = false}) async {
    for (final rows in _byDay.values) {
      final index = rows.indexWhere((row) => row.id == id);
      if (index >= 0) {
        rows.removeAt(index);
        return;
      }
    }
    throw StateError('البند غير موجود');
  }

  @override
  Future<MonthlyPersonal> monthlyPersonal(String date) async {
    final fixed = monthlyOverride;
    if (fixed != null) {
      return fixed;
    }
    final personal = [
      for (final rows in _byDay.values)
        for (final row in rows)
          if (row.kind == ExpenseKind.personal) row,
    ];
    return MonthlyPersonal(
      count: personal.length,
      total: personal.fold<int>(0, (sum, row) => sum + row.amount),
    );
  }
}
