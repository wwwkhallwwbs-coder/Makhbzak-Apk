import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:makhbazak/data/app_database.dart';
import 'package:makhbazak/data/day_repository.dart';
import 'package:makhbazak/data/device_repository.dart';
import 'package:makhbazak/data/distribution_repository.dart';
import 'package:makhbazak/data/models.dart';
import 'package:makhbazak/data/settings_repository.dart';
import 'package:makhbazak/features/distribution/distribution_controller.dart';
import 'package:makhbazak/features/production/production_controller.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// أرقام المواصفة §4.1: مجموع الإنتاج 9,040.
const List<int> _specSacks = [905, 900, 910, 895, 902, 908, 899, 905, 903, 913];

/// اختبارات متحكم الشباك والتوزيع على القاعدة الحقيقية (ffi). «اليوم» ثابت:
/// 2026-11-24، وبداية الوكيل 2026-11-23.
void main() {
  sqfliteFfiInit();

  late Database db;
  late DeviceInfo device;
  late DayRepository days;
  late DistributionRepository distribution;
  late SettingsRepository settings;
  late DistributionController controller;
  late String schemaSql;

  final DateTime today = DateTime(2026, 11, 24, 10);

  setUpAll(() {
    schemaSql = File('assets/db/schema.sql').readAsStringSync();
  });

  setUp(() async {
    db = await openAppDatabase(
      schemaSql: schemaSql,
      path: inMemoryDatabasePath,
      factory: databaseFactoryFfi,
    );
    device = await DeviceRepository(db).activateAsAgent(
      codeHash: 'a' * 64,
      bakeryName: 'مخبز التجربة',
      agentName: 'وكيل التجربة',
      startedAt: '2026-11-23',
    );
    settings = SettingsRepository(
      db,
      bakeryId: device.bakeryId!,
      deviceId: device.id,
    );
    days = DayRepository(
      db,
      bakeryId: device.bakeryId!,
      agentId: device.agentId!,
      deviceId: device.id,
    );
    distribution = DistributionRepository(
      db,
      bakeryId: device.bakeryId!,
      deviceId: device.id,
    );
    controller = DistributionController(
      days: days,
      distribution: distribution,
      settings: settings,
      clock: () => today,
    );
  });

  tearDown(() async {
    controller.dispose();
    await db.close();
  });

  Future<void> setPrices() async {
    await settings.set(SettingKeys.windowPrice, 100);
    await settings.set(SettingKeys.distributionPrice, 90);
  }

  Future<void> openToday() async {
    await setPrices();
    await controller.load();
    await controller.openDay();
  }

  Future<void> fillProduction(List<int> sacks) async {
    final dayId = controller.day!.id;
    for (var i = 0; i < sacks.length; i++) {
      await days.setSack(dayId, i + 1, sacks[i]);
    }
  }

  group('التحميل وفتح اليوم', () {
    test('يبدأ بتاريخ اليوم ويوم غير مفتوح', () async {
      await setPrices();
      await controller.load();

      expect(controller.loading, isFalse);
      expect(controller.date, '2026-11-24');
      expect(controller.isToday, isTrue);
      expect(controller.day, isNull);
      expect(controller.window, isNull);
      expect(controller.totals, isNull);
      expect(controller.canGoPrevious, isTrue);
      expect(controller.canGoNext, isFalse);
    });

    test('فتح اليوم بلا أسعار في الإعدادات يطلب الإعدادات', () async {
      await controller.load();
      await controller.openDay();

      expect(controller.needsSettings, isTrue);
      expect(controller.day, isNull);
    });

    test('اليوم المفتوح بلا موزعين: الشباك كله إنتاج اليوم', () async {
      await openToday();
      await fillProduction(_specSacks);
      await controller.load();

      expect(controller.day, isNotNull);
      expect(controller.rows, isEmpty);
      expect(controller.totals!.loaves, 0);
      expect(controller.window!.totalLoaves, 9040);
      expect(controller.window!.windowLoaves, 9040);
      expect(controller.window!.windowRevenue, 904000);
      expect(controller.overDistributed, isFalse);
    });
  });

  group('الموزعون', () {
    test('الإضافة تعطي أسماء مبدئية، والتسمية تعدّل الاسم', () async {
      await openToday();
      await controller.addDistributor();
      await controller.addDistributor();

      expect(controller.rows.map((r) => r.name).toList(), [
        'الموزع الأول',
        'الموزع الثاني',
      ]);
      expect(controller.error, isNull);

      final problem = await controller.renameDistributor(
        controller.rows.first.distributorId,
        'مطعم النيل',
      );
      expect(problem, isNull);
      expect(controller.rows.first.name, 'مطعم النيل');
    });

    test('الاسم المكرر والفارغ يرجعان رسالة ولا يغيّران شيئاً', () async {
      await openToday();
      await controller.addDistributor();
      await controller.addDistributor();
      final second = controller.rows[1].distributorId;

      final duplicate = await controller.renameDistributor(second, 'الموزع الأول');
      expect(duplicate, isNotNull);
      final empty = await controller.renameDistributor(second, '   ');
      expect(empty, isNotNull);
      expect(controller.rows[1].name, 'الموزع الثاني');
    });

    test('الإضافة قبل فتح اليوم ترجع خطأ «افتح اليوم أولاً»', () async {
      await setPrices();
      await controller.load();
      await controller.addDistributor();

      expect(controller.error, 'افتح اليوم أولاً');
      expect(await distribution.distributors(), isEmpty);
    });
  });

  group('أرقام المواصفة §4.2', () {
    test('730 موزَّعة: مستحق 65,700 ومسدد 52,500 ومتبقٍ 13,200، وشباك 8,310 بإيراد 831,000', () async {
      await openToday();
      await fillProduction(_specSacks);
      for (var i = 0; i < 3; i++) {
        await controller.addDistributor();
      }
      const loaves = [250, 300, 180];
      const paid = [22500, 20000, 10000];
      final ids = controller.rows.map((r) => r.distributorId).toList();
      for (var i = 0; i < 3; i++) {
        await controller.setLoaves(ids[i], loaves[i]);
        await controller.setPaid(ids[i], paid[i]);
      }

      expect(controller.error, isNull);
      expect(controller.lines.map((l) => l.remaining).toList(), [0, 7000, 6200]);
      final totals = controller.totals!;
      expect(totals.loaves, 730);
      expect(totals.due, 65700);
      expect(totals.paid, 52500);
      expect(totals.remaining, 13200);
      final window = controller.window!;
      expect(window.totalLoaves, 9040);
      expect(window.distributedLoaves, 730);
      expect(window.windowLoaves, 8310);
      expect(window.windowRevenue, 831000);
      expect(controller.overDistributed, isFalse);
    });

    test('الموزَّع أكبر من الإنتاج يُنبَّه إليه', () async {
      await openToday();
      await fillProduction([900]);
      await controller.addDistributor();
      final id = controller.rows.single.distributorId;

      await controller.setLoaves(id, 800);
      expect(controller.overDistributed, isFalse);
      await controller.setLoaves(id, 1000);
      expect(controller.overDistributed, isTrue);
      expect(controller.window!.windowLoaves, -100);
    });

    test('الكتابة السريعة المتتابعة تُنفَّذ بترتيبها', () async {
      await openToday();
      await controller.addDistributor();
      final id = controller.rows.single.distributorId;

      final writes = <Future<void>>[
        controller.setLoaves(id, 10),
        controller.setLoaves(id, 20),
        controller.setLoaves(id, 30),
        controller.setPaid(id, 500),
      ];
      await Future.wait(writes);

      expect(controller.rows.single.loaves, 30);
      expect(controller.rows.single.paid, 500);
    });
  });

  group('الأسعار', () {
    test('تعديل سعر اليوم الحالي يغيّر اليوم والإعدادات معاً', () async {
      await openToday();
      await controller.setWindowPrice(120);
      await controller.setDistributionPrice(95);

      expect(controller.day!.windowPrice, 120);
      expect(controller.day!.distributionPrice, 95);
      expect(await settings.getInt(SettingKeys.windowPrice), 120);
      expect(await settings.getInt(SettingKeys.distributionPrice), 95);
    });

    test('سعر التوزيع الجديد يغيّر المستحق', () async {
      await openToday();
      await controller.addDistributor();
      final id = controller.rows.single.distributorId;
      await controller.setLoaves(id, 100);
      expect(controller.lines.single.due, 9000);

      await controller.setDistributionPrice(95);
      expect(controller.lines.single.due, 9500);
    });

    test('تعديل سعر يوم سابق يغيّر ذلك اليوم فقط', () async {
      await setPrices();
      await controller.load('2026-11-23');
      await controller.openDay();
      expect(controller.isToday, isFalse);

      await controller.setWindowPrice(110);

      expect(controller.day!.windowPrice, 110);
      expect(await settings.getInt(SettingKeys.windowPrice), 100);
    });
  });

  group('اليوم المقفل', () {
    test('للقراءة فقط: الكتابة عليه تعطي رسالة القفل ولا تغيّر شيئاً', () async {
      await openToday();
      await controller.addDistributor();
      final id = controller.rows.single.distributorId;
      await controller.setLoaves(id, 250);
      await db.rawUpdate(
        "UPDATE days SET status = 'locked', locked_at = '2026-11-24T20:00:00Z' WHERE id = ?",
        [controller.day!.id],
      );
      await controller.load();

      expect(controller.isLocked, isTrue);
      expect(controller.rows.single.loaves, 250);

      await controller.setLoaves(id, 999);
      expect(controller.error, lockedDayMessage);
      await controller.setWindowPrice(500);
      expect(controller.error, lockedDayMessage);
      await controller.addDistributor();
      expect(controller.error, lockedDayMessage);

      final row = (await distribution.rowsForDay(
        controller.day!.id,
        onlyWithEntries: true,
      ))
          .single;
      expect(row.loaves, 250);
      expect(controller.day!.windowPrice, 100);
    });
  });

  group('التنقل', () {
    test('الأمام لا يتجاوز اليوم، والخلف لا يسبق بداية الوكيل', () async {
      await setPrices();
      await controller.load();

      await controller.goToNext();
      expect(controller.date, '2026-11-24');

      await controller.goToPrevious();
      expect(controller.date, '2026-11-23');
      expect(controller.canGoPrevious, isFalse);

      await controller.goToPrevious();
      expect(controller.date, '2026-11-23');
    });
  });
}
