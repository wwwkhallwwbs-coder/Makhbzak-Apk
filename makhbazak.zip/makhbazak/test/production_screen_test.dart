import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:makhbazak/features/production/production_controller.dart';
import 'package:makhbazak/features/production/production_screen.dart';

import 'support/fakes.dart';

const List<int> _specSacks = [905, 900, 910, 895, 902, 908, 899, 905, 903, 913];

const ValueKey<String> _countKey = ValueKey<String>('sack-count');

const String _today = '2026-11-24';

/// اختبارات عرض الشاشة وتفاعلها. المستودع بديل في الذاكرة (test/support)،
/// فكل شيء يجري في الزمن المزيَّف: لا قاعدة بيانات ولا دخل/خرج فعلي.
void main() {
  // شاشة طويلة ليُبنى كل الصف دفعة واحدة (القائمة تبني الظاهر فقط).
  void useTallScreen(WidgetTester tester) {
    tester.view.physicalSize = const Size(800, 3000);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
  }

  /// يمرّر الزمن بما يكفي لتنتهي عمليات المتحكم (طابور من microtasks) وتُعاد
  /// الرسوم والحركات.
  Future<void> settle(WidgetTester tester) async {
    for (var i = 0; i < 3; i++) {
      await tester.pump(const Duration(milliseconds: 300));
    }
  }

  ProductionController buildController(
    FakeDays days, {
    Map<String, int>? planned,
  }) {
    return ProductionController(
      days: days,
      clock: () => DateTime(2026, 11, 24, 10),
      plannedCounts: planned,
    );
  }

  Future<void> show(WidgetTester tester, ProductionController controller) async {
    await tester.pumpWidget(
      MaterialApp(
        home: ProductionScreen(
          controller: controller,
          onOpenSettings: () async {},
        ),
      ),
    );
    await settle(tester);
  }

  testWidgets('يعرض أرقام المواصفة كما في التصميم', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today, loaves: _specSacks);
    await show(tester, buildController(days));

    // الترويسة: العنوان والتاريخ بالعربية.
    expect(find.text('الإنتاج اليومي'), findsOneWidget);
    expect(find.text('الثلاثاء 24 نوفمبر 2026 · اليوم'), findsOneWidget);

    // ثلاث خانات: المجموع والمتوسط والمستهدف.
    expect(find.text('المجموع الكلي'), findsOneWidget);
    expect(find.text('9,040'), findsOneWidget);
    expect(find.text('المتوسط'), findsOneWidget);
    expect(find.text('904'), findsOneWidget);
    expect(find.text('المستهدف'), findsOneWidget);

    // سطر الفرق والمفروض والشارة.
    expect(
      find.text('إنتاج اليوم زائد عن المفروض بـ 40 عيشة'),
      findsOneWidget,
    );
    expect(find.text('المفروض 9,000 (10 جوالات × 900)'), findsOneWidget);
    expect(find.text('+40'), findsOneWidget);

    // العنوان «القطعيات» وعدد الجوالات وعشر خانات مرقمة.
    expect(find.text('القطعيات'), findsOneWidget);
    expect(find.text('عدد الجوالات'), findsOneWidget);
    expect(tester.widget<TextField>(find.byKey(_countKey)).controller!.text, '10');
    expect(find.byType(TextField), findsNWidgets(11));
    expect(find.text('إضافة جوال'), findsOneWidget);
    expect(find.textContaining('سُجّل'), findsNothing);
  });

  testWidgets('يوم مفتوح بلا جوالات: يُطلب العدد أولاً ولا خانات ولا سطر فرق', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today);
    await show(tester, buildController(days));

    expect(find.text('اكتب عدد الجوالات لتظهر خانات القطعيات'), findsOneWidget);
    expect(find.text('عدد الجوالات'), findsOneWidget);
    expect(find.byType(TextField), findsOneWidget);
    expect(find.textContaining('عن المفروض'), findsNothing);
    expect(find.textContaining('مطابق للمفروض'), findsNothing);
    expect(find.text('إضافة جوال'), findsNothing);
  });

  testWidgets('كتابة العدد تُظهر خانات مرقمة، و«إضافة جوال» تزيد خانة', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today);
    await show(tester, buildController(days));

    await tester.enterText(find.byKey(_countKey), '3');
    await settle(tester);

    // خانة العدد + ثلاث خانات، وكلها فارغة.
    expect(find.byType(TextField), findsNWidgets(4));
    expect(find.text('سُجّل 0 من 3'), findsOneWidget);
    expect(find.text('اكتب عدد الجوالات لتظهر خانات القطعيات'), findsNothing);

    await tester.tap(find.text('إضافة جوال'));
    await settle(tester);

    expect(find.byType(TextField), findsNWidgets(5));
    expect(find.text('سُجّل 0 من 4'), findsOneWidget);
    expect(tester.widget<TextField>(find.byKey(_countKey)).controller!.text, '4');
  });

  testWidgets('كتابة عيش جوال تحسب المجموع فوراً', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today);
    await show(tester, buildController(days, planned: {_today: 2}));

    // خانة العدد ثم خانتا الجوالين.
    expect(find.byType(TextField), findsNWidgets(3));
    await tester.enterText(find.byType(TextField).at(1), '905');
    await settle(tester);

    expect(find.text('سُجّل 1 من 2'), findsOneWidget);
    expect(find.text('المفروض 900 (1 جوال × 900)'), findsOneWidget);
    expect(find.text('+5'), findsOneWidget);
  });

  testWidgets('بعض الخانات معبأة: يظهر «سُجّل 2 من 5» والحساب على المعبأ فقط', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today, loaves: [905, 895]);
    await show(tester, buildController(days, planned: {_today: 5}));

    expect(find.text('سُجّل 2 من 5'), findsOneWidget);
    expect(find.byType(TextField), findsNWidgets(6));
    expect(find.text('1,800'), findsOneWidget);
    expect(find.text('المفروض 1,800 (2 جوال × 900)'), findsOneWidget);
    expect(find.textContaining('مطابق للمفروض'), findsOneWidget);
  });

  testWidgets('اليوم غير المفتوح: زر فتح اليوم يفتحه', (tester) async {
    useTallScreen(tester);
    await show(tester, buildController(FakeDays()));

    expect(find.text('لم يُفتح هذا اليوم بعد'), findsOneWidget);
    expect(find.text('فتح اليوم'), findsOneWidget);
    expect(find.text('عدد الجوالات'), findsNothing);
    expect(find.text('إضافة جوال'), findsNothing);

    await tester.tap(find.text('فتح اليوم'));
    await settle(tester);

    expect(find.text('لم يُفتح هذا اليوم بعد'), findsNothing);
    expect(find.text('عدد الجوالات'), findsOneWidget);
    expect(find.text('اكتب عدد الجوالات لتظهر خانات القطعيات'), findsOneWidget);
  });

  testWidgets('اليوم غير المفتوح والأسعار ناقصة: دعوة لفتح الإعدادات', (tester) async {
    useTallScreen(tester);
    await show(tester, buildController(FakeDays(hasSettings: false)));

    await tester.tap(find.text('فتح اليوم'));
    await settle(tester);

    expect(find.text('فتح الإعدادات'), findsOneWidget);
    expect(find.text('عدد الجوالات'), findsNothing);
  });

  testWidgets('اليوم المقفل: شريط القفل بلا حقول إدخال ولا عدد ولا إضافة', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today, loaves: [905], locked: true);
    await show(tester, buildController(days));

    expect(find.text(lockedDayMessage), findsOneWidget);
    expect(find.byType(TextField), findsNothing);
    expect(find.text('عدد الجوالات'), findsNothing);
    expect(find.text('إضافة جوال'), findsNothing);
    expect(find.text('القطعيات'), findsOneWidget);
    expect(find.text('905'), findsWidgets);
  });

  testWidgets('السهم يعرض اليوم السابق (غير مفتوح)، ولا يتجاوز اليوم الحالي', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today, loaves: _specSacks);
    await show(tester, buildController(days));

    await tester.tap(find.byTooltip('اليوم السابق'));
    await settle(tester);

    expect(find.text('الإثنين 23 نوفمبر 2026'), findsOneWidget);
    expect(find.text('لم يُفتح هذا اليوم بعد'), findsOneWidget);
  });
}
