import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:makhbazak/data/settings_repository.dart';
import 'package:makhbazak/features/distribution/distribution_controller.dart';
import 'package:makhbazak/features/distribution/distribution_screen.dart';
import 'package:makhbazak/features/production/production_controller.dart';

import 'support/fakes.dart';

const List<int> _specSacks = [905, 900, 910, 895, 902, 908, 899, 905, 903, 913];

const String _today = '2026-11-24';

const ValueKey<String> _windowPriceKey = ValueKey<String>('window-price');
const ValueKey<String> _nameKey = ValueKey<String>('distributor-name');

/// اختبارات شاشة الشباك والتوزيع. المستودعات بدائل في الذاكرة (test/support)،
/// فكل شيء في الزمن المزيَّف بلا قاعدة بيانات.
void main() {
  void useTallScreen(WidgetTester tester) {
    tester.view.physicalSize = const Size(800, 3000);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
  }

  Future<void> settle(WidgetTester tester) async {
    for (var i = 0; i < 3; i++) {
      await tester.pump(const Duration(milliseconds: 300));
    }
  }

  DistributionController buildController(
    FakeDays days,
    FakeDistribution distribution,
    FakeSettings settings,
  ) {
    return DistributionController(
      days: days,
      distribution: distribution,
      settings: settings,
      clock: () => DateTime(2026, 11, 24, 10),
    );
  }

  Future<void> show(WidgetTester tester, DistributionController controller) async {
    await tester.pumpWidget(
      MaterialApp(
        home: DistributionScreen(
          controller: controller,
          onOpenSettings: () async {},
        ),
      ),
    );
    await settle(tester);
  }

  /// يوم مفتوح بإنتاج المواصفة (9,040) وثلاثة موزعين بأرقام §4.2:
  /// 250 و300 و180 عيشة (730)، المسدد 22,500 و20,000 و10,000.
  ({
    FakeDays days,
    FakeDistribution distribution,
    FakeSettings settings,
    List<String> ids,
  }) specSetup() {
    final days = FakeDays();
    final day = days.seedDay(_today, loaves: _specSacks);
    final distribution = FakeDistribution();
    final ids = <String>[];
    const loaves = [250, 300, 180];
    const paid = [22500, 20000, 10000];
    const names = ['أحمد', 'بشير', 'كافتيريا الجامعة'];
    for (var i = 0; i < names.length; i++) {
      final info = distribution.seed(names[i]);
      ids.add(info.id);
      distribution.seedLoaves(day.id, info.id, loaves[i]);
      distribution.seedPaid(day.id, info.id, paid[i]);
    }
    return (days: days, distribution: distribution, settings: FakeSettings(), ids: ids);
  }

  testWidgets('يعرض أرقام المواصفة §4.2 كما في التصميم', (tester) async {
    useTallScreen(tester);
    final s = specSetup();
    await show(tester, buildController(s.days, s.distribution, s.settings));

    expect(find.text('الشباك والتوزيع'), findsOneWidget);
    expect(find.text('الثلاثاء 24 نوفمبر 2026 · اليوم'), findsOneWidget);

    // الأسعار.
    expect(find.text('الأسعار'), findsOneWidget);
    expect(tester.widget<TextField>(find.byKey(_windowPriceKey)).controller!.text, '100');
    expect(
      tester
          .widget<TextField>(find.byKey(const ValueKey<String>('distribution-price')))
          .controller!
          .text,
      '90',
    );

    // حساب الشباك: 9,040 − 730 = 8,310 عيشة، وإيراده 831,000.
    expect(find.text('حساب الشباك'), findsOneWidget);
    expect(find.text('9,040'), findsOneWidget);
    expect(find.text('−730'), findsOneWidget);
    expect(find.text('8,310'), findsOneWidget);
    expect(find.text('831,000'), findsOneWidget);
    expect(find.textContaining('أكبر من إنتاج اليوم'), findsNothing);

    // جدول الموزعين.
    expect(find.text('الموزعون'), findsOneWidget);
    expect(find.text('أحمد'), findsOneWidget);
    expect(find.text('بشير'), findsOneWidget);
    expect(find.text('كافتيريا الجامعة'), findsOneWidget);
    expect(find.text('22,500'), findsOneWidget);
    expect(find.text('27,000'), findsOneWidget);
    expect(find.text('16,200'), findsOneWidget);

    // الإجمالي: 730 عيشة، مستحق 65,700، مسدد 52,500، متبقٍ 13,200.
    expect(find.text('الإجمالي'), findsOneWidget);
    expect(find.text('730'), findsOneWidget);
    expect(find.text('65,700'), findsOneWidget);
    expect(find.text('52,500'), findsOneWidget);
    expect(find.text('13,200'), findsOneWidget);
    expect(find.text('7,000'), findsOneWidget);
    expect(find.text('6,200'), findsOneWidget);
    expect(find.textContaining('ينتقل إلى حساب الغد'), findsOneWidget);

    // خانتا السعر + (الكمية والمسدد) لكل موزع.
    expect(find.byType(TextField), findsNWidgets(8));
    expect(find.text('إضافة موزع'), findsOneWidget);
  });

  testWidgets('كتابة كمية موزع تحدّث الشباك فوراً', (tester) async {
    useTallScreen(tester);
    final days = FakeDays();
    final day = days.seedDay(_today, loaves: _specSacks);
    final distribution = FakeDistribution();
    final info = distribution.seed('أحمد');
    final controller = buildController(days, distribution, FakeSettings());
    await show(tester, controller);

    expect(find.text('9,040'), findsOneWidget);
    await tester.enterText(find.byKey(ValueKey<String>('loaves-${info.id}')), '100');
    await settle(tester);

    expect(find.text('−100'), findsOneWidget);
    expect(find.text('8,940'), findsOneWidget);
    expect(find.text('894,000'), findsOneWidget);
    final rows = await distribution.rowsForDay(day.id, onlyWithEntries: false);
    expect(rows.single.loaves, 100);
  });

  testWidgets('تعديل سعر الشباك لليوم الحالي يحدّث الإيراد والإعدادات', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today, loaves: _specSacks);
    final settings = FakeSettings();
    await show(tester, buildController(days, FakeDistribution(), settings));

    expect(find.text('904,000'), findsOneWidget);
    await tester.enterText(find.byKey(_windowPriceKey), '120');
    await settle(tester);

    // 9,040 × 120.
    expect(find.text('1,084,800'), findsOneWidget);
    expect(settings.saved[SettingKeys.windowPrice], 120);
  });

  testWidgets('«إضافة موزع» تضيف صفاً باسم مبدئي', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today, loaves: _specSacks);
    await show(tester, buildController(days, FakeDistribution(), FakeSettings()));

    expect(find.byType(TextField), findsNWidgets(2));
    await tester.tap(find.text('إضافة موزع'));
    await settle(tester);

    expect(find.text('الموزع الأول'), findsOneWidget);
    expect(find.byType(TextField), findsNWidgets(4));

    await tester.tap(find.text('إضافة موزع'));
    await settle(tester);

    expect(find.text('الموزع الثاني'), findsOneWidget);
    expect(find.byType(TextField), findsNWidgets(6));
  });

  testWidgets('الضغط على اسم الموزع يفتح نافذة التسمية ويحفظ الاسم الجديد', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today, loaves: _specSacks);
    final distribution = FakeDistribution()..seed('الموزع الأول');
    await show(tester, buildController(days, distribution, FakeSettings()));

    await tester.tap(find.text('الموزع الأول'));
    await settle(tester);
    expect(find.text('اسم الموزع'), findsOneWidget);

    await tester.enterText(find.byKey(_nameKey), 'مطعم النيل');
    await tester.tap(find.text('حفظ'));
    await settle(tester);

    expect(find.text('اسم الموزع'), findsNothing);
    expect(find.text('مطعم النيل'), findsOneWidget);
    expect(find.text('الموزع الأول'), findsNothing);
  });

  testWidgets('اسم مكرر: تبقى النافذة مفتوحة مع رسالة', (tester) async {
    useTallScreen(tester);
    final days = FakeDays()..seedDay(_today, loaves: _specSacks);
    final distribution = FakeDistribution()
      ..seed('أحمد')
      ..seed('بشير');
    await show(tester, buildController(days, distribution, FakeSettings()));

    await tester.tap(find.text('بشير'));
    await settle(tester);
    await tester.enterText(find.byKey(_nameKey), 'أحمد');
    await tester.tap(find.text('حفظ'));
    await settle(tester);

    expect(find.text('اسم الموزع'), findsOneWidget);
    expect(find.text('يوجد موزع بهذا الاسم'), findsOneWidget);

    await tester.tap(find.text('إلغاء'));
    await settle(tester);
    expect(find.text('اسم الموزع'), findsNothing);
    expect(find.text('بشير'), findsOneWidget);
  });

  testWidgets('الموزَّع أكبر من الإنتاج: تنبيه', (tester) async {
    useTallScreen(tester);
    final days = FakeDays();
    final day = days.seedDay(_today, loaves: [900]);
    final distribution = FakeDistribution();
    final info = distribution.seed('أحمد');
    distribution.seedLoaves(day.id, info.id, 1000);
    await show(tester, buildController(days, distribution, FakeSettings()));

    expect(find.textContaining('أكبر من إنتاج اليوم'), findsOneWidget);
  });

  testWidgets('اليوم غير المفتوح: زر فتح اليوم يفتحه', (tester) async {
    useTallScreen(tester);
    await show(tester, buildController(FakeDays(), FakeDistribution(), FakeSettings()));

    expect(find.text('لم يُفتح هذا اليوم بعد'), findsOneWidget);
    expect(find.text('حساب الشباك'), findsNothing);

    await tester.tap(find.text('فتح اليوم'));
    await settle(tester);

    expect(find.text('لم يُفتح هذا اليوم بعد'), findsNothing);
    expect(find.text('حساب الشباك'), findsOneWidget);
  });

  testWidgets('اليوم المقفل: قراءة فقط، ولا يظهر إلا من سُجّل له شيء', (tester) async {
    useTallScreen(tester);
    final days = FakeDays();
    final day = days.seedDay(_today, loaves: _specSacks, locked: true);
    final distribution = FakeDistribution();
    final a = distribution.seed('أحمد');
    distribution.seed('بشير');
    distribution.seedLoaves(day.id, a.id, 250);
    await show(tester, buildController(days, distribution, FakeSettings()));

    expect(find.text(lockedDayMessage), findsOneWidget);
    expect(find.byType(TextField), findsNothing);
    expect(find.text('إضافة موزع'), findsNothing);
    expect(find.text('أحمد'), findsOneWidget);
    expect(find.text('بشير'), findsNothing);
  });
}
