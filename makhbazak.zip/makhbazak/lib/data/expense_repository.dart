import 'package:sqflite/sqflite.dart';

import 'models.dart';
import 'util.dart';

/// أقصى طول لاسم بند المصروفات.
const int maxExpenseNameLength = 40;

/// بنود المصروفات في الأيام، وقوالب البنود الثابتة.
///
/// الثابتة تُنسخ من القوالب إلى كل يوم جديد (انظر `DayRepository.getOrCreate`).
/// وما يُغيَّر في **اليوم الحالي** من بند ثابت (إضافة أو تعديل أو حذف) ينتقل إلى
/// قالبه أيضاً عند [syncTemplate] فيبقى أثره في الأيام القادمة، أما الأيام
/// السابقة فيتغير فيها ذلك اليوم وحده. القالب يُطابَق باسم البند.
///
/// لا حذف فعلي: الإلغاء بـ cancelled_at. اليوم المقفل للقراءة فقط: أي كتابة
/// عليه ترفعها القاعدة نفسها (DatabaseException من الـ triggers).
class ExpenseRepository {
  ExpenseRepository(
    this._db, {
    required this.bakeryId,
    required this.agentId,
    required this.deviceId,
  });

  final Database _db;
  final String bakeryId;
  final String agentId;
  final String deviceId;

  static const String _fixedFilter = "scope = 'general' AND kind = 'fixed'";

  /// بنود اليوم الفعالة بترتيب إضافتها.
  Future<List<ExpenseRow>> forDay(String dayId) async {
    final rows = await _db.query(
      'expenses',
      columns: ['id', 'scope', 'kind', 'name', 'amount'],
      where: 'day_id = ? AND cancelled_at IS NULL',
      whereArgs: [dayId],
      orderBy: 'rowid',
    );
    return rows
        .map(
          (row) => ExpenseRow(
            id: row['id']! as String,
            kind: _kindOf(row['scope']! as String, row['kind'] as String?),
            name: row['name']! as String,
            amount: row['amount']! as int,
          ),
        )
        .toList();
  }

  /// قوالب البنود الثابتة الفعالة (ما يُنسخ إلى كل يوم جديد).
  Future<List<ExpenseRow>> templates() async {
    final rows = await _db.query(
      'expense_templates',
      columns: ['id', 'name', 'amount'],
      where: 'bakery_id = ? AND active = 1 AND cancelled_at IS NULL',
      whereArgs: [bakeryId],
      orderBy: 'rowid',
    );
    return rows
        .map(
          (row) => ExpenseRow(
            id: row['id']! as String,
            kind: ExpenseKind.fixed,
            name: row['name']! as String,
            amount: row['amount']! as int,
          ),
        )
        .toList();
  }

  /// يضيف بنداً إلى اليوم. البند الثابت لا يتكرر اسمه في اليوم نفسه.
  Future<ExpenseRow> add(
    String dayId,
    ExpenseKind kind,
    String name,
    int amount, {
    bool syncTemplate = false,
  }) async {
    final cleaned = _cleanName(name);
    _checkAmount(amount);
    if (kind == ExpenseKind.fixed && await _fixedNameTaken(_db, dayId, cleaned)) {
      throw StateError('يوجد بند ثابت بهذا الاسم');
    }
    final stamp = nowIso();
    final id = newId();
    await _db.transaction((txn) async {
      await txn.insert('expenses', {
        'id': id,
        'day_id': dayId,
        'scope': kind == ExpenseKind.personal ? 'agent_personal' : 'general',
        'kind': switch (kind) {
          ExpenseKind.fixed => 'fixed',
          ExpenseKind.variable => 'variable',
          ExpenseKind.personal => null,
        },
        'name': cleaned,
        'amount': amount,
        'device_id': deviceId,
        'created_at': stamp,
        'updated_at': stamp,
      });
      if (kind == ExpenseKind.fixed && syncTemplate) {
        await _saveTemplate(txn, null, cleaned, amount, stamp);
      }
    });
    return ExpenseRow(id: id, kind: kind, name: cleaned, amount: amount);
  }

  /// يعدّل اسم بند ومبلغه.
  Future<void> update(
    String id,
    String name,
    int amount, {
    bool syncTemplate = false,
  }) async {
    final cleaned = _cleanName(name);
    _checkAmount(amount);
    final current = await _active(_db, id);
    final fixed = current.scope == 'general' && current.kind == 'fixed';
    if (fixed &&
        await _fixedNameTaken(_db, current.dayId, cleaned, exceptId: id)) {
      throw StateError('يوجد بند ثابت بهذا الاسم');
    }
    final stamp = nowIso();
    await _db.transaction((txn) async {
      await txn.update(
        'expenses',
        {
          'name': cleaned,
          'amount': amount,
          'updated_at': stamp,
          'synced': 0,
          'device_id': deviceId,
        },
        where: 'id = ?',
        whereArgs: [id],
      );
      if (fixed && syncTemplate) {
        await _saveTemplate(txn, current.name, cleaned, amount, stamp);
      }
    });
  }

  /// يلغي بنداً (يبقى في السجل بـ cancelled_at ولا يدخل الحساب).
  Future<void> cancel(String id, {bool syncTemplate = false}) async {
    final current = await _active(_db, id);
    final stamp = nowIso();
    await _db.transaction((txn) async {
      await txn.update(
        'expenses',
        {
          'cancelled_at': stamp,
          'updated_at': stamp,
          'synced': 0,
          'device_id': deviceId,
        },
        where: 'id = ?',
        whereArgs: [id],
      );
      if (current.scope == 'general' && current.kind == 'fixed' && syncTemplate) {
        await txn.update(
          'expense_templates',
          {
            'active': 0,
            'cancelled_at': stamp,
            'updated_at': stamp,
            'synced': 0,
            'device_id': deviceId,
          },
          where: 'bakery_id = ? AND name = ? AND active = 1 AND cancelled_at IS NULL',
          whereArgs: [bakeryId, current.name],
        );
      }
    });
  }

  /// مصروفات الوكيل الشخصية في شهر [date] (`YYYY-MM-DD`): عددها ومجموعها،
  /// من كل أيام الشهر بما فيها المقفلة.
  Future<MonthlyPersonal> monthlyPersonal(String date) async {
    final month = date.substring(0, 7);
    final rows = await _db.rawQuery(
      'SELECT COUNT(*) AS n, COALESCE(SUM(e.amount), 0) AS total '
      'FROM expenses e JOIN days d ON d.id = e.day_id '
      'WHERE d.bakery_id = ? AND d.agent_id = ? AND substr(d.date, 1, 7) = ? '
      "AND e.scope = 'agent_personal' AND e.cancelled_at IS NULL",
      [bakeryId, agentId, month],
    );
    final row = rows.first;
    return MonthlyPersonal(
      count: row['n']! as int,
      total: row['total']! as int,
    );
  }

  ExpenseKind _kindOf(String scope, String? kind) {
    if (scope == 'agent_personal') {
      return ExpenseKind.personal;
    }
    return kind == 'fixed' ? ExpenseKind.fixed : ExpenseKind.variable;
  }

  Future<_Current> _active(DatabaseExecutor txn, String id) async {
    final rows = await txn.query(
      'expenses',
      columns: ['day_id', 'scope', 'kind', 'name'],
      where: 'id = ? AND cancelled_at IS NULL',
      whereArgs: [id],
      limit: 1,
    );
    if (rows.isEmpty) {
      throw StateError('البند غير موجود');
    }
    final row = rows.first;
    return _Current(
      dayId: row['day_id']! as String,
      scope: row['scope']! as String,
      kind: row['kind'] as String?,
      name: row['name']! as String,
    );
  }

  Future<bool> _fixedNameTaken(
    DatabaseExecutor txn,
    String dayId,
    String name, {
    String? exceptId,
  }) async {
    final rows = await txn.query(
      'expenses',
      columns: ['id'],
      where: exceptId == null
          ? "day_id = ? AND name = ? AND $_fixedFilter AND cancelled_at IS NULL"
          : "day_id = ? AND name = ? AND $_fixedFilter AND cancelled_at IS NULL AND id <> ?",
      whereArgs: exceptId == null ? [dayId, name] : [dayId, name, exceptId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  /// يحدّث قالب [oldName] (أو القالب باسم [name] إن لم يُعطَ اسم قديم)،
  /// وينشئه إن لم يوجد.
  Future<void> _saveTemplate(
    DatabaseExecutor txn,
    String? oldName,
    String name,
    int amount,
    String stamp,
  ) async {
    final updated = await txn.update(
      'expense_templates',
      {
        'name': name,
        'amount': amount,
        'updated_at': stamp,
        'synced': 0,
        'device_id': deviceId,
      },
      where: 'bakery_id = ? AND name = ? AND active = 1 AND cancelled_at IS NULL',
      whereArgs: [bakeryId, oldName ?? name],
    );
    if (updated == 0) {
      await txn.insert('expense_templates', {
        'id': newId(),
        'bakery_id': bakeryId,
        'name': name,
        'amount': amount,
        'device_id': deviceId,
        'created_at': stamp,
        'updated_at': stamp,
      });
    }
  }

  String _cleanName(String name) {
    final cleaned = name.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (cleaned.isEmpty) {
      throw ArgumentError('اكتب اسم البند');
    }
    if (cleaned.length > maxExpenseNameLength) {
      throw ArgumentError('الاسم أطول من $maxExpenseNameLength حرفاً');
    }
    return cleaned;
  }

  void _checkAmount(int amount) {
    if (amount < 0) {
      throw ArgumentError('المبلغ لا يكون سالباً');
    }
  }
}

class _Current {
  const _Current({
    required this.dayId,
    required this.scope,
    required this.kind,
    required this.name,
  });

  final String dayId;
  final String scope;
  final String? kind;
  final String name;
}
