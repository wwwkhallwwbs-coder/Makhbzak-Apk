import 'package:sqflite/sqflite.dart';

import '../core/labels_ar.dart';
import 'models.dart';
import 'util.dart';

/// أقصى طول لاسم الموزع.
const int maxDistributorNameLength = 40;

/// الموزعون (على مستوى المخبز) وما يُسجَّل لكل منهم في اليوم.
///
/// لا حذف فعلي. اليوم المقفل للقراءة فقط: أي كتابة عليه ترفعها القاعدة نفسها
/// (DatabaseException من الـ triggers). المستحق والمتبقي لا يُخزَّنان، بل
/// يُحسبان من الكمية وسعر التوزيع في اليوم (انظر `lib/core/accounting.dart`).
class DistributionRepository {
  DistributionRepository(
    this._db, {
    required this.bakeryId,
    required this.deviceId,
  });

  final Database _db;
  final String bakeryId;
  final String deviceId;

  /// الموزعون الفعالون بترتيب إضافتهم.
  Future<List<DistributorInfo>> distributors() async {
    final rows = await _db.query(
      'distributors',
      columns: ['id', 'name'],
      where: 'bakery_id = ? AND active = 1 AND cancelled_at IS NULL',
      whereArgs: [bakeryId],
      orderBy: 'rowid',
    );
    return rows
        .map(
          (row) => DistributorInfo(
            id: row['id']! as String,
            name: row['name']! as String,
          ),
        )
        .toList();
  }

  /// يضيف موزعاً. بلا [name] يأخذ أول اسم مبدئي غير مستعمل
  /// («الموزع الأول»، «الموزع الثاني» …) ليغيّره الوكيل لاحقاً.
  Future<DistributorInfo> addDistributor([String? name]) async {
    final wanted = name == null ? await _nextDefaultName() : _cleanName(name);
    if (await _nameTaken(wanted)) {
      throw StateError('يوجد موزع بهذا الاسم');
    }
    final stamp = nowIso();
    final id = newId();
    await _db.insert('distributors', {
      'id': id,
      'bakery_id': bakeryId,
      'name': wanted,
      'device_id': deviceId,
      'created_at': stamp,
      'updated_at': stamp,
    });
    return DistributorInfo(id: id, name: wanted);
  }

  /// يغيّر اسم موزع. الاسم المكرر يُرفض.
  Future<void> renameDistributor(String id, String name) async {
    final wanted = _cleanName(name);
    if (await _nameTaken(wanted, exceptId: id)) {
      throw StateError('يوجد موزع بهذا الاسم');
    }
    await _db.update(
      'distributors',
      {
        'name': wanted,
        'updated_at': nowIso(),
        'synced': 0,
        'device_id': deviceId,
      },
      where: 'id = ? AND bakery_id = ?',
      whereArgs: [id, bakeryId],
    );
  }

  /// صفوف اليوم. اليوم المفتوح يعرض كل الموزعين الفعالين (بصفر لمن لم يُسجَّل
  /// له شيء)، واليوم المقفل لا يعرض إلا من سُجّل له شيء في ذلك اليوم.
  Future<List<DistributionRow>> rowsForDay(
    String dayId, {
    required bool onlyWithEntries,
  }) async {
    final rows = onlyWithEntries
        ? await _db.rawQuery(
            'SELECT p.id AS id, p.name AS name, x.loaves AS loaves, '
            'x.amount_paid AS paid '
            'FROM distributors p '
            'JOIN distributions x ON x.distributor_id = p.id '
            'AND x.day_id = ? AND x.cancelled_at IS NULL '
            'WHERE p.bakery_id = ? ORDER BY p.rowid',
            [dayId, bakeryId],
          )
        : await _db.rawQuery(
            'SELECT p.id AS id, p.name AS name, '
            'COALESCE(x.loaves, 0) AS loaves, '
            'COALESCE(x.amount_paid, 0) AS paid '
            'FROM distributors p '
            'LEFT JOIN distributions x ON x.distributor_id = p.id '
            'AND x.day_id = ? AND x.cancelled_at IS NULL '
            'WHERE p.bakery_id = ? AND p.active = 1 AND p.cancelled_at IS NULL '
            'ORDER BY p.rowid',
            [dayId, bakeryId],
          );
    return rows
        .map(
          (row) => DistributionRow(
            distributorId: row['id']! as String,
            name: row['name']! as String,
            loaves: row['loaves']! as int,
            paid: row['paid']! as int,
          ),
        )
        .toList();
  }

  /// يسجّل الكمية الموزَّعة لموزع في اليوم (الصف يُنشأ عند أول تسجيل).
  Future<void> setLoaves(String dayId, String distributorId, int loaves) async {
    if (loaves < 0) {
      throw ArgumentError.value(loaves, 'loaves', 'الكمية لا تكون سالبة');
    }
    await _save(dayId, distributorId, loaves: loaves);
  }

  /// يسجّل المبلغ المسدد من الموزع في اليوم. قد يزيد عن مستحق اليوم إذا كان
  /// يسدد دين يوم سابق.
  Future<void> setPaid(String dayId, String distributorId, int paid) async {
    if (paid < 0) {
      throw ArgumentError.value(paid, 'paid', 'المبلغ لا يكون سالباً');
    }
    await _save(dayId, distributorId, paid: paid);
  }

  /// تحديث ثم إضافة (بلا UPSERT). الحقل غير المذكور يبقى كما هو، أو صفراً عند
  /// إنشاء الصف.
  Future<void> _save(
    String dayId,
    String distributorId, {
    int? loaves,
    int? paid,
  }) async {
    final stamp = nowIso();
    await _db.transaction((txn) async {
      final updated = await txn.update(
        'distributions',
        {
          if (loaves != null) 'loaves': loaves,
          if (paid != null) 'amount_paid': paid,
          'cancelled_at': null,
          'updated_at': stamp,
          'synced': 0,
          'device_id': deviceId,
        },
        where: 'day_id = ? AND distributor_id = ?',
        whereArgs: [dayId, distributorId],
      );
      if (updated == 0) {
        await txn.insert('distributions', {
          'id': newId(),
          'day_id': dayId,
          'distributor_id': distributorId,
          'loaves': loaves ?? 0,
          'amount_paid': paid ?? 0,
          'device_id': deviceId,
          'created_at': stamp,
          'updated_at': stamp,
        });
      }
    });
  }

  String _cleanName(String name) {
    final cleaned = name.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (cleaned.isEmpty) {
      throw ArgumentError('اكتب اسم الموزع');
    }
    if (cleaned.length > maxDistributorNameLength) {
      throw ArgumentError('الاسم أطول من $maxDistributorNameLength حرفاً');
    }
    return cleaned;
  }

  /// الاسم مستعمل في المخبز (يشمل غير الفعالين، فالمخطط يمنع التكرار مطلقاً).
  Future<bool> _nameTaken(String name, {String? exceptId}) async {
    final rows = await _db.query(
      'distributors',
      columns: ['id'],
      where: exceptId == null
          ? 'bakery_id = ? AND name = ?'
          : 'bakery_id = ? AND name = ? AND id <> ?',
      whereArgs: exceptId == null ? [bakeryId, name] : [bakeryId, name, exceptId],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<String> _nextDefaultName() async {
    var n = 1;
    while (await _nameTaken(defaultDistributorName(n))) {
      n++;
    }
    return defaultDistributorName(n);
  }
}
