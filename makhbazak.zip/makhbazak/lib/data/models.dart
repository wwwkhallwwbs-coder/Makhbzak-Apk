/// جهاز مُفعَّل: دوره والمخبز والوكيل المرتبطان به.
class DeviceInfo {
  const DeviceInfo({
    required this.id,
    required this.role,
    required this.bakeryId,
    required this.agentId,
  });

  /// معرّف الجهاز في القاعدة (يُكتب في عمود device_id لكل صف ينشئه).
  final String id;

  /// `agent` أو `owner`.
  final String role;
  final String? bakeryId;
  final String? agentId;
}

/// يوم عمل: الأسعار والمستهدف منسوخة إليه عند إنشائه، فلا يتغير حسابه لاحقاً.
class DayRecord {
  const DayRecord({
    required this.id,
    required this.date,
    required this.status,
    required this.windowPrice,
    required this.distributionPrice,
    required this.targetPerSack,
    required this.batchSizeKg,
  });

  final String id;

  /// `YYYY-MM-DD`.
  final String date;

  /// `open` أو `locked`.
  final String status;
  final int windowPrice;
  final int distributionPrice;
  final int targetPerSack;
  final double batchSizeKg;

  bool get isLocked => status == 'locked';
}

/// قطعيات جوال واحد: seq رقم الجوال، وloaves عدد العيش.
class SackEntry {
  const SackEntry({required this.seq, required this.loaves});

  final int seq;
  final int loaves;
}

/// موزع (اسمه قابل للتعديل) على مستوى المخبز.
class DistributorInfo {
  const DistributorInfo({required this.id, required this.name});

  final String id;
  final String name;
}

/// صف موزع في يوم: كميته والمسدد منه (صفر إن لم يُسجَّل شيء بعد).
class DistributionRow {
  const DistributionRow({
    required this.distributorId,
    required this.name,
    required this.loaves,
    required this.paid,
  });

  final String distributorId;
  final String name;
  final int loaves;
  final int paid;
}

/// نوع بند المصروفات: ثابت يومي (يُنسخ لكل يوم جديد) أو متحرك (لهذا اليوم فقط)،
/// وكلاهما عام يُخصم من إيراد الشباك، أو شخصي للوكيل يُخصم من راتبه شهرياً.
enum ExpenseKind { fixed, variable, personal }

/// بند مصروف في يوم (أو قالب بند ثابت).
class ExpenseRow {
  const ExpenseRow({
    required this.id,
    required this.kind,
    required this.name,
    required this.amount,
  });

  final String id;
  final ExpenseKind kind;
  final String name;
  final int amount;
}

/// مجموع مصروفات الوكيل الشخصية في شهر.
class MonthlyPersonal {
  const MonthlyPersonal({required this.count, required this.total});

  final int count;
  final int total;
}
