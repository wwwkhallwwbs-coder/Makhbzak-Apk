import 'package:flutter/material.dart';

import '../../core/labels_ar.dart';

/// ألوان وعناصر مشتركة بين شاشات اليوم (الإنتاج والتوزيع والمصروفات …)
/// حسب التصميم المعتمد: ترويسة خضراء وبطاقات بيضاء مدوّرة.
const Color brandGreen = Color(0xFF0E6B58);
const Color brandGreenSoft = Color(0xFFE3F1ED);
const Color pageBackground = Color(0xFFF5F6F4);
const Color textPrimary = Color(0xFF1B2421);
const Color textSecondary = Color(0xFF5B6761);
const Color borderColor = Color(0xFFD9DEDB);
const Color dangerColor = Color(0xFFB42318);
const Color dangerSoft = Color(0xFFFDECEA);
const Color warningColor = Color(0xFF7A4B00);
const Color warningSoft = Color(0xFFFDF0D5);

/// الترويسة الخضراء: العنوان والتاريخ بالعربية، وسهما اليوم السابق والتالي.
PreferredSizeWidget buildDayAppBar({
  required String title,
  required String date,
  required bool isToday,
  required bool canMove,
  required bool canGoPrevious,
  required bool canGoNext,
  required VoidCallback onPrevious,
  required VoidCallback onNext,
}) {
  final subtitle = date.isEmpty ? null : '${arabicDateLabel(date)}${isToday ? ' · اليوم' : ''}';
  return AppBar(
    backgroundColor: brandGreen,
    foregroundColor: Colors.white,
    surfaceTintColor: Colors.transparent,
    scrolledUnderElevation: 0,
    centerTitle: false,
    toolbarHeight: 68,
    title: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
        ),
        if (subtitle != null)
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: Color(0xFFD7EFE8),
            ),
          ),
      ],
    ),
    actions: [
      IconButton(
        tooltip: 'اليوم السابق',
        color: Colors.white,
        disabledColor: Colors.white38,
        onPressed: canMove && canGoPrevious ? onPrevious : null,
        icon: const Icon(Icons.chevron_right),
      ),
      IconButton(
        tooltip: 'اليوم التالي',
        color: Colors.white,
        disabledColor: Colors.white38,
        onPressed: canMove && canGoNext ? onNext : null,
        icon: const Icon(Icons.chevron_left),
      ),
    ],
  );
}

/// بطاقة بيضاء بحواف مدوّرة كما في التصميم.
class DayPanel extends StatelessWidget {
  const DayPanel({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE5E8E6)),
      ),
      child: child,
    );
  }
}

/// عنوان بطاقة («القطعيات»، «الأسعار» …).
class PanelTitle extends StatelessWidget {
  const PanelTitle(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 17,
        fontWeight: FontWeight.w700,
        color: textPrimary,
      ),
    );
  }
}

/// شكل خانات الإدخال الرقمية.
InputDecoration boxDecoration({
  String? hint,
  double verticalPadding = 11,
  double horizontalPadding = 12,
  double radius = 12,
}) {
  final normal = OutlineInputBorder(
    borderRadius: BorderRadius.circular(radius),
    borderSide: const BorderSide(color: borderColor),
  );
  return InputDecoration(
    hintText: hint,
    hintStyle: const TextStyle(color: Color(0xFFB0B7B3)),
    isDense: true,
    filled: true,
    fillColor: Colors.white,
    contentPadding: EdgeInsets.symmetric(
      horizontal: horizontalPadding,
      vertical: verticalPadding,
    ),
    border: normal,
    enabledBorder: normal,
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius),
      borderSide: const BorderSide(color: brandGreen, width: 1.6),
    ),
  );
}

/// شريط خطأ قابل للإخفاء.
class DayErrorBanner extends StatelessWidget {
  const DayErrorBanner({super.key, required this.message, required this.onClose});

  final String message;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: dangerSoft,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline, color: dangerColor),
          const SizedBox(width: 8),
          Expanded(
            child: Text(message, style: const TextStyle(color: dangerColor)),
          ),
          IconButton(
            tooltip: 'إخفاء',
            onPressed: onClose,
            icon: const Icon(Icons.close, color: dangerColor),
          ),
        ],
      ),
    );
  }
}

/// شريط تنبيه أصفر (قفل اليوم، أو رقم مشكوك فيه).
class DayWarningBanner extends StatelessWidget {
  const DayWarningBanner({super.key, required this.message, this.icon = Icons.warning_amber_rounded});

  final String message;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: warningSoft,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(icon, color: warningColor),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(color: warningColor, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}

/// اليوم المعروض لم يُفتح بعد: زر فتحه، أو الدعوة لإدخال الأسعار أولاً.
class DayNotOpened extends StatelessWidget {
  const DayNotOpened({
    super.key,
    required this.needsSettings,
    required this.onOpenDay,
    required this.onOpenSettings,
  });

  final bool needsSettings;
  final VoidCallback onOpenDay;
  final VoidCallback onOpenSettings;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 48),
      child: Column(
        children: [
          const Icon(Icons.event_note_outlined, size: 56, color: textSecondary),
          const SizedBox(height: 12),
          const Text(
            'لم يُفتح هذا اليوم بعد',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 20),
          if (needsSettings) ...[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: warningSoft,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'أدخل سعر الشباك وسعر التوزيع في الإعدادات أولاً، ثم يُفتح اليوم.',
                style: TextStyle(color: warningColor),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.tonal(
              onPressed: onOpenSettings,
              child: const Text('فتح الإعدادات'),
            ),
          ] else
            FilledButton.icon(
              onPressed: onOpenDay,
              icon: const Icon(Icons.add),
              label: const Text('فتح اليوم'),
            ),
        ],
      ),
    );
  }
}

/// شاشة فشل التحميل مع زر إعادة المحاولة.
class DayLoadFailed extends StatelessWidget {
  const DayLoadFailed({super.key, required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SelectableText(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: onRetry,
              child: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }
}
