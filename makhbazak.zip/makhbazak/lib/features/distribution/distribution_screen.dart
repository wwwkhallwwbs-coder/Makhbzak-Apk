import 'package:flutter/material.dart';

import '../../core/accounting.dart';
import '../../core/labels_ar.dart';
import '../../core/numbers.dart';
import '../../data/distribution_repository.dart' show maxDistributorNameLength;
import '../../data/models.dart';
import '../common/day_widgets.dart';
import '../production/production_controller.dart' show lockedDayMessage;
import 'distribution_controller.dart';

// عرض الأعمدة في جدول الموزعين (نسب)، من اليمين: الموزع، الكمية، المستحق، المسدد، المتبقي.
const int _flexName = 28;
const int _flexQty = 21;
const int _flexDue = 22;
const int _flexPaid = 22;
const int _flexRemaining = 21;

/// شاشة «الشباك والتوزيع»: أسعار اليوم، وحساب الشباك، وجدول الموزعين
/// (الكمية والمستحق والمسدد والمتبقي) حسب التصميم المعتمد.
///
/// تملك [controller] وتتخلص منه عند إغلاقها. الحفظ تلقائي مع كل تعديل.
class DistributionScreen extends StatefulWidget {
  const DistributionScreen({
    super.key,
    required this.controller,
    required this.onOpenSettings,
  });

  final DistributionController controller;

  /// يفتح شاشة الإعدادات (عند عدم اكتمال الأسعار).
  final Future<void> Function() onOpenSettings;

  @override
  State<DistributionScreen> createState() => _DistributionScreenState();
}

class _DistributionScreenState extends State<DistributionScreen> {
  @override
  void initState() {
    super.initState();
    widget.controller.ensureLoaded();
  }

  @override
  void dispose() {
    widget.controller.dispose();
    super.dispose();
  }

  Future<void> _openSettings() async {
    await widget.onOpenSettings();
    if (mounted) {
      await widget.controller.openDay();
    }
  }

  Future<void> _rename(DistributionRow row) {
    return showDialog<void>(
      context: context,
      builder: (_) => _RenameDialog(
        initial: row.name,
        onSave: (name) => widget.controller.renameDistributor(row.distributorId, name),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: pageBackground,
          appBar: buildDayAppBar(
            title: 'الشباك والتوزيع',
            date: controller.date,
            isToday: controller.isToday,
            canMove: !controller.loading,
            canGoPrevious: controller.canGoPrevious,
            canGoNext: controller.canGoNext,
            onPrevious: () => controller.goToPrevious(),
            onNext: () => controller.goToNext(),
          ),
          body: SafeArea(child: _body(controller)),
        );
      },
    );
  }

  Widget _body(DistributionController controller) {
    if (controller.loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (controller.loadFailed) {
      return DayLoadFailed(
        message: controller.error ?? 'تعذر تحميل اليوم',
        onRetry: () => controller.load(),
      );
    }
    final day = controller.day;
    final window = controller.window;
    final totals = controller.totals;
    return ListView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      children: [
        if (controller.error != null)
          DayErrorBanner(
            message: controller.error!,
            onClose: controller.dismissError,
          ),
        if (day == null || window == null || totals == null)
          DayNotOpened(
            needsSettings: controller.needsSettings,
            onOpenDay: () => controller.openDay(),
            onOpenSettings: () => _openSettings(),
          )
        else ...[
          if (day.isLocked) ...[
            const DayWarningBanner(
              message: lockedDayMessage,
              icon: Icons.lock_outline,
            ),
            const SizedBox(height: 12),
          ],
          _PricesCard(controller: controller, day: day),
          const SizedBox(height: 12),
          _WindowCard(controller: controller, window: window),
          const SizedBox(height: 12),
          _DistributorsCard(
            controller: controller,
            totals: totals,
            locked: day.isLocked,
            onRename: _rename,
          ),
          if (!day.isLocked) ...[
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton.icon(
                onPressed: () {
                  // نغلق لوحة المفاتيح قبل ظهور الصف الجديد.
                  FocusScope.of(context).unfocus();
                  controller.addDistributor();
                },
                icon: const Icon(Icons.add),
                label: const Text('إضافة موزع'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: brandGreen,
                  side: const BorderSide(color: brandGreen),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          _Footnote(locked: day.isLocked, remaining: totals.remaining),
        ],
      ],
    );
  }
}

/// بطاقة الأسعار: سعر عيشة الشباك وسعر عيشة التوزيع لهذا اليوم.
class _PricesCard extends StatelessWidget {
  const _PricesCard({required this.controller, required this.day});

  final DistributionController controller;
  final DayRecord day;

  @override
  Widget build(BuildContext context) {
    final locked = day.isLocked;
    return DayPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PanelTitle('الأسعار'),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _PriceField(
                  label: 'سعر عيشة الشباك',
                  fieldKey: const ValueKey<String>('window-price'),
                  value: day.windowPrice,
                  editable: !locked,
                  onChanged: controller.setWindowPrice,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _PriceField(
                  label: 'سعر عيشة التوزيع',
                  fieldKey: const ValueKey<String>('distribution-price'),
                  value: day.distributionPrice,
                  editable: !locked,
                  onChanged: controller.setDistributionPrice,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PriceField extends StatelessWidget {
  const _PriceField({
    required this.label,
    required this.fieldKey,
    required this.value,
    required this.editable,
    required this.onChanged,
  });

  final String label;
  final Key fieldKey;
  final int value;
  final bool editable;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 12, color: textSecondary)),
        const SizedBox(height: 6),
        _NumberCell(
          key: fieldKey,
          value: value,
          editable: editable,
          emptyMeansZero: false,
          compact: false,
          action: TextInputAction.next,
          onChanged: onChanged,
        ),
      ],
    );
  }
}

/// حساب الشباك: المجموع الكلي − الموزَّع للخارج = عيش الشباك، وإيراده.
class _WindowCard extends StatelessWidget {
  const _WindowCard({required this.controller, required this.window});

  final DistributionController controller;
  final WindowAccount window;

  @override
  Widget build(BuildContext context) {
    final distributed = window.distributedLoaves;
    return DayPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PanelTitle('حساب الشباك'),
          const SizedBox(height: 8),
          _InfoRow(
            label: 'المجموع الكلي للعيش',
            value: formatThousands(window.totalLoaves),
          ),
          _InfoRow(
            label: 'الموزَّع للخارج',
            value: distributed > 0 ? '−${formatThousands(distributed)}' : '0',
            valueColor: distributed > 0 ? dangerColor : null,
          ),
          _InfoRow(
            label: 'عيش الشباك',
            value: formatThousands(window.windowLoaves),
            valueColor: window.windowLoaves < 0 ? dangerColor : null,
            divider: false,
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: brandGreenSoft,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'إيراد الشباك',
                    style: TextStyle(fontSize: 14, color: brandGreen),
                  ),
                ),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(
                    formatThousands(window.windowRevenue),
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                      color: brandGreen,
                    ),
                  ),
                ),
              ],
            ),
          ),
          if (controller.overDistributed) ...[
            const SizedBox(height: 10),
            const DayWarningBanner(
              message: 'الموزَّع أكبر من إنتاج اليوم: راجع الكميات أو القطعيات',
            ),
          ],
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.label,
    required this.value,
    this.valueColor,
    this.divider = true,
  });

  final String label;
  final String value;
  final Color? valueColor;
  final bool divider;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: divider
          ? const BoxDecoration(
              border: Border(bottom: BorderSide(color: Color(0xFFEDF0EE))),
            )
          : null,
      child: Row(
        children: [
          Expanded(
            child: Text(label, style: const TextStyle(fontSize: 14, color: textPrimary)),
          ),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Text(
              value,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: valueColor ?? textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// جدول الموزعين: الاسم (يُضغط لتعديله) والكمية والمستحق والمسدد والمتبقي، وصف الإجمالي.
class _DistributorsCard extends StatelessWidget {
  const _DistributorsCard({
    required this.controller,
    required this.totals,
    required this.locked,
    required this.onRename,
  });

  final DistributionController controller;
  final DistributionTotals totals;
  final bool locked;
  final void Function(DistributionRow row) onRename;

  @override
  Widget build(BuildContext context) {
    final rows = controller.rows;
    final lines = controller.lines;
    return DayPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PanelTitle('الموزعون'),
          const SizedBox(height: 12),
          const _HeaderRow(),
          if (rows.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Center(
                child: Text(
                  locked
                      ? 'لا موزعين مسجلين في هذا اليوم'
                      : 'اضغط «إضافة موزع» لإضافة أول موزع',
                  style: const TextStyle(color: textSecondary),
                ),
              ),
            )
          else ...[
            for (var i = 0; i < rows.length; i++)
              _DistributorRow(
                key: ValueKey<String>(rows[i].distributorId),
                row: rows[i],
                line: lines[i],
                locked: locked,
                isLast: i == rows.length - 1,
                onRename: onRename,
                onLoaves: (value) => controller.setLoaves(rows[i].distributorId, value),
                onPaid: (value) => controller.setPaid(rows[i].distributorId, value),
              ),
            _TotalRow(totals: totals),
          ],
        ],
      ),
    );
  }
}

class _HeaderRow extends StatelessWidget {
  const _HeaderRow();

  Widget _cell(int flex, String text, {bool start = false}) {
    return Expanded(
      flex: flex,
      child: Text(
        text,
        textAlign: start ? TextAlign.start : TextAlign.center,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: textSecondary,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF1F3F2),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          _cell(_flexName, 'الموزع', start: true),
          _cell(_flexQty, 'الكمية'),
          _cell(_flexDue, 'المستحق'),
          _cell(_flexPaid, 'المسدد'),
          _cell(_flexRemaining, 'المتبقي'),
        ],
      ),
    );
  }
}

/// لون المتبقي: أحمر إن بقي على الموزع شيء، وأخضر إن سدد كل شيء.
Color _remainingColor(int remaining) => remaining > 0 ? dangerColor : brandGreen;

class _DistributorRow extends StatelessWidget {
  const _DistributorRow({
    super.key,
    required this.row,
    required this.line,
    required this.locked,
    required this.isLast,
    required this.onRename,
    required this.onLoaves,
    required this.onPaid,
  });

  final DistributionRow row;
  final DistributorLine line;
  final bool locked;
  final bool isLast;
  final void Function(DistributionRow row) onRename;
  final ValueChanged<int> onLoaves;
  final ValueChanged<int> onPaid;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 6),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFFEDF0EE))),
      ),
      child: Row(
        children: [
          Expanded(
            flex: _flexName,
            // Material شفاف فوق البطاقة البيضاء ليظهر أثر الضغط.
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: locked ? null : () => onRename(row),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 2),
                  child: Text(
                    row.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      decoration: locked ? null : TextDecoration.underline,
                      decorationStyle: TextDecorationStyle.dashed,
                      decorationColor: textSecondary,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            flex: _flexQty,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: _NumberCell(
                key: ValueKey<String>('loaves-${row.distributorId}'),
                value: row.loaves,
                editable: !locked,
                emptyMeansZero: true,
                compact: true,
                action: TextInputAction.next,
                onChanged: onLoaves,
              ),
            ),
          ),
          Expanded(
            flex: _flexDue,
            child: _PlainNumber(formatThousands(line.due)),
          ),
          Expanded(
            flex: _flexPaid,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: _NumberCell(
                key: ValueKey<String>('paid-${row.distributorId}'),
                value: row.paid,
                editable: !locked,
                emptyMeansZero: true,
                compact: true,
                action: isLast ? TextInputAction.done : TextInputAction.next,
                onChanged: onPaid,
              ),
            ),
          ),
          Expanded(
            flex: _flexRemaining,
            child: _PlainNumber(
              formatThousands(line.remaining),
              color: _remainingColor(line.remaining),
              bold: true,
            ),
          ),
        ],
      ),
    );
  }
}

class _TotalRow extends StatelessWidget {
  const _TotalRow({required this.totals});

  final DistributionTotals totals;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
      child: Row(
        children: [
          const Expanded(
            flex: _flexName,
            child: Text(
              'الإجمالي',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
            ),
          ),
          Expanded(
            flex: _flexQty,
            child: _PlainNumber(formatThousands(totals.loaves), bold: true),
          ),
          Expanded(
            flex: _flexDue,
            child: _PlainNumber(formatThousands(totals.due), bold: true),
          ),
          Expanded(
            flex: _flexPaid,
            child: _PlainNumber(formatThousands(totals.paid), bold: true),
          ),
          Expanded(
            flex: _flexRemaining,
            child: _PlainNumber(
              formatThousands(totals.remaining),
              color: _remainingColor(totals.remaining),
              bold: true,
            ),
          ),
        ],
      ),
    );
  }
}

/// رقم للقراءة فقط في خلية الجدول.
class _PlainNumber extends StatelessWidget {
  const _PlainNumber(this.text, {this.color, this.bold = false});

  final String text;
  final Color? color;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    // الأرقام الكبيرة تصغر لتبقى في خانتها بدل أن تُقصّ.
    return Center(
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Text(
          text,
          maxLines: 1,
          style: TextStyle(
            fontSize: 13,
            fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
            color: color ?? textPrimary,
          ),
        ),
      ),
    );
  }
}

/// التذييل: شرح تعديل الاسم، وأن المتبقي على الموزعين ينتقل إلى حساب الغد.
class _Footnote extends StatelessWidget {
  const _Footnote({required this.locked, required this.remaining});

  final bool locked;
  final int remaining;

  @override
  Widget build(BuildContext context) {
    final parts = <String>[
      if (!locked) 'اضغط على اسم الموزع لتكتب اسمه.',
      if (remaining > 0)
        'المتبقي على الموزعين (${formatThousands(remaining)}) ينتقل إلى حساب الغد تلقائياً.',
    ];
    if (parts.isEmpty) {
      return const SizedBox.shrink();
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Text(
        parts.join(' '),
        style: const TextStyle(fontSize: 12, color: textSecondary, height: 1.5),
      ),
    );
  }
}

/// خانة رقم قابلة للتعديل: كل رقم صالح يُحفظ فوراً. الفارغ يُحسب صفراً في خانات
/// الجدول ([emptyMeansZero])، ويُتجاهل في الأسعار (يعود المحفوظ عند ترك الخانة).
class _NumberCell extends StatefulWidget {
  const _NumberCell({
    super.key,
    required this.value,
    required this.editable,
    required this.emptyMeansZero,
    required this.compact,
    required this.action,
    required this.onChanged,
  });

  final int value;
  final bool editable;
  final bool emptyMeansZero;

  /// خلية جدول صغيرة (الكمية والمسدد) أو خانة كبيرة (الأسعار).
  final bool compact;
  final TextInputAction action;
  final ValueChanged<int> onChanged;

  @override
  State<_NumberCell> createState() => _NumberCellState();
}

class _NumberCellState extends State<_NumberCell> {
  late final TextEditingController _text =
      TextEditingController(text: _display(widget.value));
  final FocusNode _focus = FocusNode();

  /// آخر قيمة أرسلناها للحفظ. نقارن بها لا بالمقروءة من القاعدة لأن القراءة
  /// تتأخر عن الكتابة (انظر خانة القطعيات).
  late int _sent = widget.value;

  String _display(int value) =>
      (widget.emptyMeansZero && value == 0) ? '' : value.toString();

  @override
  void initState() {
    super.initState();
    _focus.addListener(_onFocusChanged);
  }

  @override
  void dispose() {
    _focus.removeListener(_onFocusChanged);
    _focus.dispose();
    _text.dispose();
    super.dispose();
  }

  /// عند ترك الخانة نعيد كتابة المحفوظ: يُصلح نصاً غير صالح، ويوحّد الأرقام العربية.
  void _onFocusChanged() {
    if (_focus.hasFocus) {
      return;
    }
    final want = _display(_sent);
    if (_text.text != want) {
      _text.text = want;
    }
  }

  void _changed(String value) {
    if (value.trim().isEmpty) {
      if (widget.emptyMeansZero && _sent != 0) {
        _sent = 0;
        widget.onChanged(0);
      }
      return;
    }
    final parsed = parseWholeNumber(value);
    if (parsed != null && parsed != _sent) {
      _sent = parsed;
      widget.onChanged(parsed);
    }
  }

  @override
  Widget build(BuildContext context) {
    final fontSize = widget.compact ? 13.0 : 16.0;
    if (!widget.editable) {
      return Container(
        padding: EdgeInsets.symmetric(vertical: widget.compact ? 8 : 11),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(color: borderColor),
          borderRadius: BorderRadius.circular(widget.compact ? 8 : 12),
        ),
        child: Text(
          formatThousands(widget.value),
          style: TextStyle(fontSize: fontSize),
        ),
      );
    }
    return TextField(
      controller: _text,
      focusNode: _focus,
      keyboardType: TextInputType.number,
      textInputAction: widget.action,
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: widget.compact ? FontWeight.w400 : FontWeight.w700,
      ),
      onChanged: _changed,
      decoration: widget.compact
          ? boxDecoration(
              hint: '0',
              verticalPadding: 8,
              horizontalPadding: 2,
              radius: 8,
            )
          : boxDecoration(),
    );
  }
}

/// نافذة تعديل اسم موزع. تملك خانة النص وتتخلص منها، وتبقى مفتوحة مع رسالة
/// إن رُفض الاسم (فارغ أو مكرر).
class _RenameDialog extends StatefulWidget {
  const _RenameDialog({required this.initial, required this.onSave});

  final String initial;

  /// يرجع رسالة المشكلة، أو null عند النجاح.
  final Future<String?> Function(String name) onSave;

  @override
  State<_RenameDialog> createState() => _RenameDialogState();
}

class _RenameDialogState extends State<_RenameDialog> {
  late final TextEditingController _text = TextEditingController(text: widget.initial);
  String? _problem;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    // الاسم المبدئي («الموزع الأول») يُستبدل عادة، فنحدده كله.
    _text.selection = TextSelection(baseOffset: 0, extentOffset: widget.initial.length);
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_busy) {
      return;
    }
    setState(() {
      _busy = true;
      _problem = null;
    });
    final result = await widget.onSave(_text.text);
    if (!mounted) {
      return;
    }
    if (result == null) {
      Navigator.of(context).pop();
    } else {
      setState(() {
        _busy = false;
        _problem = result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('اسم الموزع'),
      content: TextField(
        key: const ValueKey<String>('distributor-name'),
        controller: _text,
        autofocus: true,
        maxLength: maxDistributorNameLength,
        textInputAction: TextInputAction.done,
        onSubmitted: (_) => _save(),
        decoration: InputDecoration(errorText: _problem, counterText: ''),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: _busy ? null : _save,
          child: const Text('حفظ'),
        ),
      ],
    );
  }
}
