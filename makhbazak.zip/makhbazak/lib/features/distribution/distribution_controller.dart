import 'package:flutter/foundation.dart';

import '../../core/accounting.dart';
import '../../data/day_repository.dart';
import '../../data/distribution_repository.dart';
import '../../data/models.dart';
import '../../data/settings_repository.dart';
import '../../data/util.dart';
import '../production/production_controller.dart' show lockedDayMessage;

/// حالة شاشة «الشباك والتوزيع»: أسعار اليوم، وحساب الشباك، وجدول الموزعين.
///
/// الشاشة لا تحسب ولا تكتب SQL: المعادلات من `lib/core/accounting.dart`
/// والكتابة عبر المستودعات. كل العمليات تُنفَّذ بترتيب استدعائها (طابور
/// واحد)، وأخطاؤها تُحفظ في [error] لتعرضها الشاشة.
class DistributionController extends ChangeNotifier {
  DistributionController({
    required DayRepository days,
    required DistributionRepository distribution,
    required SettingsRepository settings,
    DateTime Function()? clock,
  })  : _days = days,
        _distribution = distribution,
        _settings = settings,
        _clock = clock ?? DateTime.now;

  final DayRepository _days;
  final DistributionRepository _distribution;
  final SettingsRepository _settings;
  final DateTime Function() _clock;

  Future<void> _pending = Future<void>.value();
  bool _disposed = false;
  bool _loaded = false;

  /// جارٍ تحميل اليوم المعروض.
  bool loading = true;

  /// فشل التحميل نفسه (تُعرض معه زر إعادة المحاولة).
  bool loadFailed = false;

  /// رسالة آخر خطأ في عملية، أو null.
  String? error;

  /// فتح اليوم يحتاج إكمال الإعدادات أولاً (الأسعار).
  bool needsSettings = false;

  /// بداية عمل الوكيل في المخبز: لا يُفتح يوم قبلها.
  String? startDate;

  /// التاريخ المعروض `YYYY-MM-DD`.
  String date = '';

  /// اليوم المعروض، أو null إن لم يُفتح بعد.
  DayRecord? day;

  /// صفوف الموزعين (اليوم المفتوح: كلهم، والمقفل: من سُجّل له شيء).
  List<DistributionRow> rows = const <DistributionRow>[];

  /// سطر حساب لكل صف في [rows] بالترتيب نفسه: المستحق والمتبقي.
  List<DistributorLine> lines = const <DistributorLine>[];

  /// إجمالي جدول الموزعين، أو null إن لم يُفتح اليوم.
  DistributionTotals? totals;

  /// حساب الشباك (المجموع الكلي − الموزَّع = عيش الشباك وإيراده)، أو null.
  WindowAccount? window;

  String get today => formatDate(_clock());

  bool get isToday => date == today;

  bool get isLocked => day?.isLocked ?? false;

  /// الموزَّع أكثر من إنتاج اليوم: غالباً خطأ في إدخال الأرقام.
  bool get overDistributed => (window?.windowLoaves ?? 0) < 0;

  bool get canGoPrevious {
    final start = startDate;
    return start != null && date.compareTo(start) > 0;
  }

  bool get canGoNext => date.compareTo(today) < 0;

  Future<void> ensureLoaded() => _loaded ? Future<void>.value() : load();

  /// يحمّل [targetDate] (الافتراضي: اليوم المعروض، وأول مرة تاريخ اليوم).
  /// التاريخ يُقيَّد بين بداية الوكيل واليوم.
  Future<void> load([String? targetDate]) {
    return _enqueue(() async {
      loading = true;
      loadFailed = false;
      error = null;
      needsSettings = false;
      _notify();
      try {
        startDate ??= await _days.agentStartDate();
        final wanted = targetDate ?? (date.isEmpty ? today : date);
        date = _clamp(wanted);
        await _refresh();
        _loaded = true;
      } on Object catch (e) {
        loadFailed = true;
        error = 'تعذر تحميل اليوم: $e';
      }
      loading = false;
      _notify();
    });
  }

  Future<void> goToPrevious() async {
    if (canGoPrevious) {
      await load(shiftDate(date, -1));
    }
  }

  Future<void> goToNext() async {
    if (canGoNext) {
      await load(shiftDate(date, 1));
    }
  }

  /// يفتح اليوم المعروض (يُنشأ بأسعار الإعدادات الحالية).
  Future<void> openDay() {
    return _enqueue(() async {
      error = null;
      needsSettings = false;
      try {
        if (!await _days.hasOpeningSettings()) {
          needsSettings = true;
        } else {
          await _days.getOrCreate(date);
          await _refresh();
        }
      } on Object catch (e) {
        error = _describe(e, 'تعذر فتح اليوم');
      }
      _notify();
    });
  }

  /// يعدّل سعر عيشة الشباك لليوم. وإن كان اليوم هو اليوم الحالي يصير أيضاً
  /// سعر الأيام القادمة (في الإعدادات)، فلا يرجع السعر القديم غداً.
  Future<void> setWindowPrice(int price) {
    return _write((current) async {
      await _days.updatePrices(current.id, windowPrice: price);
      if (isToday) {
        await _settings.set(SettingKeys.windowPrice, price);
      }
    });
  }

  /// يعدّل سعر عيشة التوزيع لليوم (ولما بعده إن كان اليوم الحالي).
  Future<void> setDistributionPrice(int price) {
    return _write((current) async {
      await _days.updatePrices(current.id, distributionPrice: price);
      if (isToday) {
        await _settings.set(SettingKeys.distributionPrice, price);
      }
    });
  }

  /// يضيف موزعاً باسم مبدئي («الموزع الأول» …) ليغيّره الوكيل بالضغط عليه.
  Future<void> addDistributor() {
    return _write((current) async {
      await _distribution.addDistributor();
    });
  }

  /// يغيّر اسم موزع. يرجع رسالة المشكلة (اسم فارغ أو مكرر)، أو null عند النجاح.
  Future<String?> renameDistributor(String distributorId, String name) async {
    String? problem;
    await _write((current) async {
      try {
        await _distribution.renameDistributor(distributorId, name);
      } on StateError catch (e) {
        problem = e.message;
      } on ArgumentError catch (e) {
        problem = '${e.message}';
      }
    });
    return problem;
  }

  /// يسجّل الكمية الموزَّعة لموزع في اليوم المعروض.
  Future<void> setLoaves(String distributorId, int loaves) {
    return _write(
      (current) => _distribution.setLoaves(current.id, distributorId, loaves),
    );
  }

  /// يسجّل المبلغ المسدد من موزع في اليوم المعروض.
  Future<void> setPaid(String distributorId, int paid) {
    return _write(
      (current) => _distribution.setPaid(current.id, distributorId, paid),
    );
  }

  void dismissError() {
    if (error != null) {
      error = null;
      _notify();
    }
  }

  Future<void> _write(Future<void> Function(DayRecord current) action) {
    return _enqueue(() async {
      final current = day;
      if (current == null) {
        error = 'افتح اليوم أولاً';
      } else if (current.isLocked) {
        error = lockedDayMessage;
      } else {
        try {
          await action(current);
          await _refresh();
          error = null;
        } on Object catch (e) {
          error = _describe(e, 'تعذر الحفظ');
        }
      }
      _notify();
    });
  }

  /// يقرأ اليوم المعروض وموزعيه من القاعدة ويحسب الشباك والإجمالي.
  Future<void> _refresh() async {
    final found = await _days.find(date);
    day = found;
    if (found == null) {
      rows = const <DistributionRow>[];
      lines = const <DistributorLine>[];
      totals = null;
      window = null;
      return;
    }
    final list = await _distribution.rowsForDay(
      found.id,
      onlyWithEntries: found.isLocked,
    );
    final production = await _days.production(found);
    final built = list
        .map(
          (row) => DistributorLine(
            name: row.name,
            loaves: row.loaves,
            paid: row.paid,
            distributionPrice: found.distributionPrice,
          ),
        )
        .toList();
    final sum = totalDistribution(built);
    rows = list;
    lines = built;
    totals = sum;
    window = computeWindowAccount(
      totalLoaves: production.total,
      distributedLoaves: sum.loaves,
      windowPrice: found.windowPrice,
    );
  }

  String _clamp(String wanted) {
    var result = wanted;
    final now = today;
    if (result.compareTo(now) > 0) {
      result = now;
    }
    final start = startDate;
    if (start != null && result.compareTo(start) < 0) {
      result = start;
    }
    return result;
  }

  String _describe(Object e, String prefix) {
    final text = e.toString();
    if (text.contains('day is locked')) {
      return lockedDayMessage;
    }
    if (text.contains('not assigned')) {
      return 'هذا التاريخ قبل بداية عملك في المخبز';
    }
    if (e is ArgumentError) {
      return '$prefix: ${e.message}';
    }
    if (e is StateError) {
      return '$prefix: ${e.message}';
    }
    return '$prefix: $text';
  }

  /// يشغّل العمليات بالترتيب، وفشل إحداها لا يوقف الطابور.
  Future<void> _enqueue(Future<void> Function() operation) {
    final next = _pending.then((_) => operation());
    _pending = next.then<void>((_) {}, onError: (Object _) {});
    return next;
  }

  void _notify() {
    if (!_disposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
