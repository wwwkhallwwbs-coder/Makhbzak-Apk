import 'package:flutter/foundation.dart';

import '../../core/accounting.dart';
import '../../data/day_repository.dart';
import '../../data/expense_repository.dart';
import '../../data/models.dart';
import '../../data/util.dart';
import '../production/production_controller.dart' show lockedDayMessage;

/// حالة شاشة «المصروفات»: البنود الثابتة والمتحركة (تُخصم من إيراد الشباك)
/// وبنود الوكيل الشخصية (يُجمع إجماليها الشهري).
///
/// الشاشة لا تحسب ولا تكتب SQL: المجاميع من `lib/core/accounting.dart` والكتابة
/// عبر المستودعات. كل العمليات تُنفَّذ بترتيب استدعائها (طابور واحد)، وأخطاؤها
/// تُحفظ في [error] لتعرضها الشاشة.
///
/// في اليوم الحالي ينتقل أثر تعديل البنود الثابتة إلى الأيام القادمة (قالبها)،
/// وفي يوم سابق يتغير ذلك اليوم وحده.
class ExpensesController extends ChangeNotifier {
  ExpensesController({
    required DayRepository days,
    required ExpenseRepository expenses,
    DateTime Function()? clock,
  })  : _days = days,
        _expenses = expenses,
        _clock = clock ?? DateTime.now;

  final DayRepository _days;
  final ExpenseRepository _expenses;
  final DateTime Function() _clock;

  Future<void> _pending = Future<void>.value();
  bool _disposed = false;
  bool _loaded = false;

  /// جارٍ تحميل اليوم المعروض.
  bool loading = true;

  /// فشل التحميل نفسه (تُعرض معه زر إعادة المحاولة).
  bool loadFailed = false;

  /// رسالة آخر خطأ في عملية، أو null.
  String? error;

  /// فتح اليوم يحتاج إكمال الإعدادات أولاً (الأسعار).
  bool needsSettings = false;

  /// بداية عمل الوكيل في المخبز: لا يُفتح يوم قبلها.
  String? startDate;

  /// التاريخ المعروض `YYYY-MM-DD`.
  String date = '';

  /// اليوم المعروض، أو null إن لم يُفتح بعد.
  DayRecord? day;

  /// البنود الثابتة والمتحركة والشخصية في اليوم المعروض.
  List<ExpenseRow> fixed = const <ExpenseRow>[];
  List<ExpenseRow> variable = const <ExpenseRow>[];
  List<ExpenseRow> personal = const <ExpenseRow>[];

  /// مجاميع الثابتة والمتحركة والشخصية (وإجمالي مصروفات البنكجي = الثابتة +
  /// المتحركة)، أو null إن لم يُفتح اليوم.
  ExpenseTotals? totals;

  /// إجمالي مصروفات الوكيل الشخصية في شهر اليوم المعروض، أو null إن لم يُفتح اليوم.
  MonthlyPersonal? monthly;

  String get today => formatDate(_clock());

  bool get isToday => date == today;

  bool get isLocked => day?.isLocked ?? false;

  bool get canGoPrevious {
    final start = startDate;
    return start != null && date.compareTo(start) > 0;
  }

  bool get canGoNext => date.compareTo(today) < 0;

  Future<void> ensureLoaded() => _loaded ? Future<void>.value() : load();

  /// يحمّل [targetDate] (الافتراضي: اليوم المعروض، وأول مرة تاريخ اليوم).
  /// التاريخ يُقيَّد بين بداية الوكيل واليوم.
  Future<void> load([String? targetDate]) {
    return _enqueue(() async {
      loading = true;
      loadFailed = false;
      error = null;
      needsSettings = false;
      _notify();
      try {
        startDate ??= await _days.agentStartDate();
        final wanted = targetDate ?? (date.isEmpty ? today : date);
        date = _clamp(wanted);
        await _refresh();
        _loaded = true;
      } on Object catch (e) {
        loadFailed = true;
        error = 'تعذر تحميل اليوم: $e';
      }
      loading = false;
      _notify();
    });
  }

  Future<void> goToPrevious() async {
    if (canGoPrevious) {
      await load(shiftDate(date, -1));
    }
  }

  Future<void> goToNext() async {
    if (canGoNext) {
      await load(shiftDate(date, 1));
    }
  }

  /// يفتح اليوم المعروض (يُنشأ بأسعار الإعدادات الحالية وبنوده الثابتة).
  Future<void> openDay() {
    return _enqueue(() async {
      error = null;
      needsSettings = false;
      try {
        if (!await _days.hasOpeningSettings()) {
          needsSettings = true;
        } else {
          await _days.getOrCreate(date);
          await _refresh();
        }
      } on Object catch (e) {
        error = _describe(e, 'تعذر فتح اليوم');
      }
      _notify();
    });
  }

  /// يضيف بنداً. يرجع رسالة المشكلة (اسم فارغ أو مكرر، مبلغ سالب)، أو null عند
  /// النجاح (وأي خطأ آخر يظهر في [error]).
  Future<String?> addItem(ExpenseKind kind, String name, int amount) {
    return _write(
      (current) => _expenses.add(
        current.id,
        kind,
        name,
        amount,
        syncTemplate: isToday,
      ),
    );
  }

  /// يعدّل اسم بند ومبلغه. يرجع رسالة المشكلة أو null.
  Future<String?> updateItem(ExpenseRow row, String name, int amount) {
    return _write(
      (current) => _expenses.update(row.id, name, amount, syncTemplate: isToday),
    );
  }

  /// يلغي بنداً (يبقى في السجل ولا يدخل الحساب).
  Future<void> removeItem(ExpenseRow row) {
    return _write(
      (current) => _expenses.cancel(row.id, syncTemplate: isToday),
    );
  }

  void dismissError() {
    if (error != null) {
      error = null;
      _notify();
    }
  }

  Future<String?> _write(Future<void> Function(DayRecord current) action) async {
    String? problem;
    await _enqueue(() async {
      final current = day;
      if (current == null) {
        error = 'افتح اليوم أولاً';
      } else if (current.isLocked) {
        error = lockedDayMessage;
      } else {
        try {
          await action(current);
          await _refresh();
          error = null;
        } on StateError catch (e) {
          problem = e.message;
        } on ArgumentError catch (e) {
          problem = '${e.message}';
        } on Object catch (e) {
          error = _describe(e, 'تعذر الحفظ');
        }
      }
      _notify();
    });
    return problem;
  }

  /// يقرأ اليوم المعروض وبنوده من القاعدة ويحسب المجاميع.
  Future<void> _refresh() async {
    final found = await _days.find(date);
    day = found;
    if (found == null) {
      fixed = const <ExpenseRow>[];
      variable = const <ExpenseRow>[];
      personal = const <ExpenseRow>[];
      totals = null;
      monthly = null;
      return;
    }
    final rows = await _expenses.forDay(found.id);
    final fixedRows = rows.where((row) => row.kind == ExpenseKind.fixed).toList();
    final variableRows = rows.where((row) => row.kind == ExpenseKind.variable).toList();
    final personalRows = rows.where((row) => row.kind == ExpenseKind.personal).toList();
    final month = await _expenses.monthlyPersonal(date);
    fixed = fixedRows;
    variable = variableRows;
    personal = personalRows;
    monthly = month;
    totals = summarizeExpenses(
      fixed: fixedRows.map((row) => row.amount).toList(),
      variable: variableRows.map((row) => row.amount).toList(),
      personal: personalRows.map((row) => row.amount).toList(),
    );
  }

  String _clamp(String wanted) {
    var result = wanted;
    final now = today;
    if (result.compareTo(now) > 0) {
      result = now;
    }
    final start = startDate;
    if (start != null && result.compareTo(start) < 0) {
      result = start;
    }
    return result;
  }

  String _describe(Object e, String prefix) {
    final text = e.toString();
    if (text.contains('day is locked')) {
      return lockedDayMessage;
    }
    if (text.contains('not assigned')) {
      return 'هذا التاريخ قبل بداية عملك في المخبز';
    }
    return '$prefix: $text';
  }

  /// يشغّل العمليات بالترتيب، وفشل إحداها لا يوقف الطابور.
  Future<void> _enqueue(Future<void> Function() operation) {
    final next = _pending.then((_) => operation());
    _pending = next.then<void>((_) {}, onError: (Object _) {});
    return next;
  }

  void _notify() {
    if (!_disposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
