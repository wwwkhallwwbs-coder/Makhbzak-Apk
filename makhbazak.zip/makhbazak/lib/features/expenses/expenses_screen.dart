import 'package:flutter/material.dart';

import '../../core/labels_ar.dart';
import '../../core/numbers.dart';
import '../../data/expense_repository.dart' show maxExpenseNameLength;
import '../../data/models.dart';
import '../common/day_widgets.dart';
import '../production/production_controller.dart' show lockedDayMessage;
import 'expenses_controller.dart';

/// شاشة «المصروفات»: ثابتة يومية، ومتحركة، وإجمالي مصروفات البنكجي، ثم مصروفات
/// الوكيل الشخصية وإجماليها الشهري (حسب التصميم المعتمد).
///
/// تملك [controller] وتتخلص منه عند إغلاقها. الإضافة والتعديل والحذف من نافذة
/// تُفتح بالضغط، والحفظ فوري.
class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({
    super.key,
    required this.controller,
    required this.onOpenSettings,
  });

  final ExpensesController controller;

  /// يفتح شاشة الإعدادات (عند عدم اكتمال الأسعار).
  final Future<void> Function() onOpenSettings;

  @override
  State<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen> {
  @override
  void initState() {
    super.initState();
    widget.controller.ensureLoaded();
  }

  @override
  void dispose() {
    widget.controller.dispose();
    super.dispose();
  }

  Future<void> _openSettings() async {
    await widget.onOpenSettings();
    if (mounted) {
      await widget.controller.openDay();
    }
  }

  String _noteFor(ExpenseKind kind) {
    switch (kind) {
      case ExpenseKind.fixed:
        return widget.controller.isToday
            ? 'بند ثابت: يُنسخ إلى كل يوم جديد.'
            : 'تغيير في يوم سابق: يخص هذا اليوم وحده.';
      case ExpenseKind.variable:
        return 'بند متحرك: لهذا اليوم فقط.';
      case ExpenseKind.personal:
        return 'يُجمع مع مصروفاتك الشخصية هذا الشهر.';
    }
  }

  String _addTitle(ExpenseKind kind) {
    switch (kind) {
      case ExpenseKind.fixed:
        return 'بند ثابت جديد';
      case ExpenseKind.variable:
        return 'بند متحرك جديد';
      case ExpenseKind.personal:
        return 'بند شخصي جديد';
    }
  }

  Future<void> _openItem(ExpenseKind kind, [ExpenseRow? row]) {
    final controller = widget.controller;
    return showDialog<void>(
      context: context,
      builder: (_) => _ItemDialog(
        title: row == null ? _addTitle(kind) : 'تعديل البند',
        note: _noteFor(kind),
        initialName: row?.name ?? '',
        initialAmount: row?.amount,
        onSave: (name, amount) => row == null
            ? controller.addItem(kind, name, amount)
            : controller.updateItem(row, name, amount),
        onDelete: row == null ? null : () => controller.removeItem(row),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: pageBackground,
          appBar: buildDayAppBar(
            title: 'المصروفات',
            date: controller.date,
            isToday: controller.isToday,
            canMove: !controller.loading,
            canGoPrevious: controller.canGoPrevious,
            canGoNext: controller.canGoNext,
            onPrevious: () => controller.goToPrevious(),
            onNext: () => controller.goToNext(),
          ),
          body: SafeArea(child: _body(controller)),
        );
      },
    );
  }

  Widget _body(ExpensesController controller) {
    if (controller.loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (controller.loadFailed) {
      return DayLoadFailed(
        message: controller.error ?? 'تعذر تحميل اليوم',
        onRetry: () => controller.load(),
      );
    }
    final day = controller.day;
    final totals = controller.totals;
    final monthly = controller.monthly;
    return ListView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
      children: [
        if (controller.error != null)
          DayErrorBanner(
            message: controller.error!,
            onClose: controller.dismissError,
          ),
        if (day == null || totals == null || monthly == null)
          DayNotOpened(
            needsSettings: controller.needsSettings,
            onOpenDay: () => controller.openDay(),
            onOpenSettings: () => _openSettings(),
          )
        else ...[
          if (day.isLocked) ...[
            const DayWarningBanner(
              message: lockedDayMessage,
              icon: Icons.lock_outline,
            ),
            const SizedBox(height: 12),
          ],
          _SectionCard(
            title: 'مصروفات ثابتة يومية',
            totalKey: const ValueKey<String>('fixed-total'),
            total: totals.fixed,
            rows: controller.fixed,
            emptyText: 'لا بنود ثابتة',
            addLabel: 'إضافة بند ثابت',
            locked: day.isLocked,
            onAdd: () => _openItem(ExpenseKind.fixed),
            onEdit: (row) => _openItem(ExpenseKind.fixed, row),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'مصروفات متحركة',
            totalKey: const ValueKey<String>('variable-total'),
            total: totals.variable,
            rows: controller.variable,
            emptyText: 'لا بنود متحركة',
            addLabel: 'إضافة بند متحرك',
            locked: day.isLocked,
            onAdd: () => _openItem(ExpenseKind.variable),
            onEdit: (row) => _openItem(ExpenseKind.variable, row),
          ),
          const SizedBox(height: 12),
          _BankajiTotal(total: totals.general),
          const SizedBox(height: 12),
          _SectionCard(
            title: 'مصروفات الوكيل الشخصية',
            totalKey: const ValueKey<String>('personal-total'),
            total: totals.personal,
            rows: controller.personal,
            emptyText: 'لا بنود شخصية اليوم',
            addLabel: 'إضافة بند للوكيل',
            locked: day.isLocked,
            onAdd: () => _openItem(ExpenseKind.personal),
            onEdit: (row) => _openItem(ExpenseKind.personal, row),
            footer: _MonthlyPersonal(monthly: monthly),
          ),
        ],
      ],
    );
  }
}

/// بطاقة قسم: عنوانه وإجماليه، وبنوده (يُضغط على البند لتعديله)، وزر الإضافة.
class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.title,
    required this.totalKey,
    required this.total,
    required this.rows,
    required this.emptyText,
    required this.addLabel,
    required this.locked,
    required this.onAdd,
    required this.onEdit,
    this.footer,
  });

  final String title;
  final Key totalKey;
  final int total;
  final List<ExpenseRow> rows;
  final String emptyText;
  final String addLabel;
  final bool locked;
  final VoidCallback onAdd;
  final void Function(ExpenseRow row) onEdit;
  final Widget? footer;

  @override
  Widget build(BuildContext context) {
    return DayPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: PanelTitle(title)),
              _Amount(
                formatThousands(total),
                key: totalKey,
                size: 17,
                bold: true,
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (rows.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Center(
                child: Text(emptyText, style: const TextStyle(color: textSecondary)),
              ),
            )
          else
            for (final row in rows)
              _ItemRow(
                key: ValueKey<String>('item-${row.id}'),
                row: row,
                onTap: locked ? null : () => onEdit(row),
              ),
          if (!locked) ...[
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              height: 46,
              child: OutlinedButton.icon(
                onPressed: onAdd,
                icon: const Icon(Icons.add),
                label: Text(addLabel),
                style: OutlinedButton.styleFrom(
                  foregroundColor: brandGreen,
                  side: const BorderSide(color: brandGreen),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
          if (footer != null) ...[
            const SizedBox(height: 12),
            footer!,
          ],
        ],
      ),
    );
  }
}

class _ItemRow extends StatelessWidget {
  const _ItemRow({super.key, required this.row, required this.onTap});

  final ExpenseRow row;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 2),
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: Color(0xFFEDF0EE))),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                row.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 14, color: textPrimary),
              ),
            ),
            const SizedBox(width: 12),
            _Amount(formatThousands(row.amount), size: 14),
            if (onTap != null) ...[
              const SizedBox(width: 6),
              const Icon(Icons.edit_outlined, size: 16, color: textSecondary),
            ],
          ],
        ),
      ),
    );
  }
}

/// مبلغ بخط ثابت الاتجاه (الفواصل والأرقام تُقرأ من اليسار).
class _Amount extends StatelessWidget {
  const _Amount(this.text, {super.key, required this.size, this.bold = false});

  final String text;
  final double size;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Text(
        text,
        style: TextStyle(
          fontSize: size,
          fontWeight: bold ? FontWeight.w700 : FontWeight.w600,
          color: textPrimary,
        ),
      ),
    );
  }
}

/// إجمالي مصروفات البنكجي = الثابتة + المتحركة (تُخصم من إيراد الشباك).
class _BankajiTotal extends StatelessWidget {
  const _BankajiTotal({required this.total});

  final int total;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: brandGreenSoft,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'إجمالي مصروفات البنكجي',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: brandGreen,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'تُخصم من إيراد الشباك',
                  style: TextStyle(fontSize: 12, color: brandGreen),
                ),
              ],
            ),
          ),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Text(
              formatThousands(total),
              key: const ValueKey<String>('bankaji-total'),
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: brandGreen,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// إجمالي الشخصية في الشهر، وتنبيه أنه يُخصم من الراتب آخر الشهر.
class _MonthlyPersonal extends StatelessWidget {
  const _MonthlyPersonal({required this.monthly});

  final MonthlyPersonal monthly;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFFF1F3F2),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  'إجمالي هذا الشهر (${itemsCountLabel(monthly.count)})',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                ),
              ),
              _Amount(
                formatThousands(monthly.total),
                key: const ValueKey<String>('month-total'),
                size: 16,
                bold: true,
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'تُجمع طوال الشهر وتُخصم من راتب الوكيل آخر الشهر، ولا تدخل في حساب اليوم.',
          style: TextStyle(fontSize: 12, color: textSecondary, height: 1.5),
        ),
      ],
    );
  }
}

/// نافذة إضافة بند أو تعديله (اسم ومبلغ). تملك خانتي النص وتتخلص منهما، وتبقى
/// مفتوحة مع رسالة إن رُفض الحفظ (اسم فارغ أو مكرر، أو مبلغ ليس رقماً).
/// الحذف على خطوتين: «حذف» ثم «تأكيد الحذف».
class _ItemDialog extends StatefulWidget {
  const _ItemDialog({
    required this.title,
    required this.note,
    required this.initialName,
    required this.initialAmount,
    required this.onSave,
    required this.onDelete,
  });

  final String title;
  final String note;
  final String initialName;
  final int? initialAmount;

  /// يرجع رسالة المشكلة، أو null عند النجاح.
  final Future<String?> Function(String name, int amount) onSave;

  /// null عند الإضافة (لا حذف).
  final Future<void> Function()? onDelete;

  @override
  State<_ItemDialog> createState() => _ItemDialogState();
}

class _ItemDialogState extends State<_ItemDialog> {
  late final TextEditingController _name = TextEditingController(text: widget.initialName);
  late final TextEditingController _amount =
      TextEditingController(text: widget.initialAmount?.toString() ?? '');
  String? _problem;
  bool _busy = false;
  bool _confirmDelete = false;

  @override
  void dispose() {
    _name.dispose();
    _amount.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_busy) {
      return;
    }
    final amount = parseWholeNumber(_amount.text);
    if (amount == null) {
      setState(() => _problem = 'اكتب المبلغ بالأرقام');
      return;
    }
    setState(() {
      _busy = true;
      _problem = null;
    });
    final result = await widget.onSave(_name.text, amount);
    if (!mounted) {
      return;
    }
    if (result == null) {
      Navigator.of(context).pop();
    } else {
      setState(() {
        _busy = false;
        _problem = result;
      });
    }
  }

  Future<void> _delete() async {
    final onDelete = widget.onDelete;
    if (_busy || onDelete == null) {
      return;
    }
    setState(() => _busy = true);
    await onDelete();
    if (!mounted) {
      return;
    }
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              key: const ValueKey<String>('expense-name'),
              controller: _name,
              autofocus: widget.initialName.isEmpty,
              maxLength: maxExpenseNameLength,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(labelText: 'اسم البند', counterText: ''),
            ),
            const SizedBox(height: 12),
            TextField(
              key: const ValueKey<String>('expense-amount'),
              controller: _amount,
              keyboardType: TextInputType.number,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _save(),
              decoration: const InputDecoration(labelText: 'المبلغ'),
            ),
            if (_problem != null) ...[
              const SizedBox(height: 10),
              Text(_problem!, style: const TextStyle(color: dangerColor)),
            ],
            const SizedBox(height: 10),
            Text(
              widget.note,
              style: const TextStyle(fontSize: 12, color: textSecondary),
            ),
          ],
        ),
      ),
      actionsOverflowButtonSpacing: 4,
      actions: [
        if (widget.onDelete != null && !_confirmDelete)
          TextButton(
            onPressed: _busy ? null : () => setState(() => _confirmDelete = true),
            style: TextButton.styleFrom(foregroundColor: dangerColor),
            child: const Text('حذف'),
          ),
        if (_confirmDelete) ...[
          TextButton(
            onPressed: _busy ? null : () => setState(() => _confirmDelete = false),
            child: const Text('تراجع'),
          ),
          FilledButton(
            onPressed: _busy ? null : _delete,
            style: FilledButton.styleFrom(backgroundColor: dangerColor),
            child: const Text('تأكيد الحذف'),
          ),
        ] else ...[
          TextButton(
            onPressed: _busy ? null : () => Navigator.of(context).pop(),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: _busy ? null : _save,
            child: const Text('حفظ'),
          ),
        ],
      ],
    );
  }
}
